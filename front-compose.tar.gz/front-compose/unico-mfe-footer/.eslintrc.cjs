/**
 * @type {import('eslint').ESLint.ConfigData}
 */
module.exports = {
  root: true,
  env: {
    node: true,
    browser: true,
    jest: true,
  },
  extends: [
    "plugin:react/recommended",
    "eslint:recommended",
    "airbnb",
    "airbnb/hooks",
    "plugin:@typescript-eslint/recommended",
    "airbnb-typescript",
    "plugin:react/jsx-runtime",
    "plugin:prettier/recommended",
  ],
  parser: "@typescript-eslint/parser",
  parserOptions: {
    ecmaFeatures: {
      jsx: true,
    },
    ecmaVersion: "latest",
    sourceType: "module",
    project: "./tsconfig.lint.json",
  },
  plugins: [
    "@typescript-eslint",
    "react",
    "jest-dom",
    "testing-library",
    "import",
    "prettier",
    "jest",
  ],
  rules: {
    // Regras de formatação de código
    "linebreak-style": ["error", "unix"],
    quotes: ["error", "double"],
    semi: ["error", "always"],
    "prettier/prettier": "error",
    "react/function-component-definition": [
      "error",
      {
        namedComponents: "arrow-function",
        unnamedComponents: "arrow-function",
      },
    ],
    // Regras desabilitadas
    "@typescript-eslint/naming-convention": "off",
    "import/prefer-default-export": "off",
    "no-nested-ternary": "off",
    "import/prefer-default-export": "off",
    "react/jsx-props-no-spreading": "off",
  },
  overrides: [
    {
      files: ["**/__tests__/**/*.[jt]s?(x)", "**/?(*.)+(spec|test).[jt]s?(x)"],
      extends: [
        "plugin:jest/all",
        "plugin:jest-dom/recommended",
        "plugin:testing-library/react",
      ],
      rules: {
        "no-explicit-any": "off",
        "jest/no-hooks": "off",
        "jest/prefer-called-with": "off",
        "jest/prefer-strict-equal": "off",
      },
      settings: {
        jest: {
          version: require("jest/package.json").version,
        },
      },
    },
  ],
};
