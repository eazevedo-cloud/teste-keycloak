import Bottom from "./Bottom/Bottom";
import Footer from "./Footer/Footer";
import LowerSection from "./LowerSection/LowerSection";
import SocialMediaDisplay from "./SocialMediaDisplay/SocialMediaDisplay";
import UpperSection from "./UpperSection/UpperSection";

export { Bottom, Footer, LowerSection, SocialMediaDisplay, UpperSection };
