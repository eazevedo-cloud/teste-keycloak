import { Box, Typography } from "@unicred/uds-core";
import { goPointsEvent } from "utils/events/goPointsEvent";
import { MENU_LINKS_MAP } from "utils/data/menuLinks";
import { UpperContainer, Button } from "./styles";
import SocialMediaDisplay from "../SocialMediaDisplay/SocialMediaDisplay";

const UpperSection = () => {
  const sendGoPointsEvent = (message: string, path: string) => {
    goPointsEvent({
      name: "unicoURLValid",
      message,
      path,
    });
  };

  return (
    <UpperContainer>
      <Box display="flex" flexDirection="column" gap={2}>
        <Typography variant="n5" color="text.secondary">
          Mapa do site
        </Typography>
        <Button
          type="button"
          onClick={() =>
            sendGoPointsEvent(
              "Produtos Unicred",
              MENU_LINKS_MAP?.PRODUTOS_UNICRED,
            )
          }
        >
          <Typography variant="body1" color="text.primary">
            Produtos Unicred
          </Typography>
        </Button>
        <Button
          type="button"
          onClick={() =>
            sendGoPointsEvent("Shopping", MENU_LINKS_MAP?.SHOPPING)
          }
        >
          <Typography variant="body1" color="text.primary">
            Shopping
          </Typography>
        </Button>
        <Button
          type="button"
          onClick={() =>
            sendGoPointsEvent(
              "Transferir pontos",
              MENU_LINKS_MAP?.TRANSFERIR_PONTOS,
            )
          }
        >
          <Typography variant="body1" color="text.primary">
            Transferir pontos
          </Typography>
        </Button>
      </Box>

      <Box display="flex" flexDirection="column" gap={2} minWidth={205}>
        <Typography variant="n5" color="text.secondary">
          Institucional
        </Typography>
        <Button
          type="button"
          onClick={() =>
            sendGoPointsEvent(
              "Regulamentos",
              MENU_LINKS_MAP?.REGULAMENTO_PROGRAMA,
            )
          }
        >
          <Typography variant="body1" color="text.primary">
            Regulamento do Programa
          </Typography>
        </Button>
        <Button
          type="button"
          onClick={() =>
            sendGoPointsEvent("Faq", MENU_LINKS_MAP?.PERGUNTAS_FREQUENTES)
          }
        >
          <Typography variant="body1" color="text.primary">
            Perguntas frequentes
          </Typography>
        </Button>
      </Box>

      <Box display="flex" flexDirection="column" gap={2}>
        <Typography variant="n5" color="text.secondary">
          Pagamentos Visa
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Business
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Impar
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Infinite
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Platinum
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Gold
        </Typography>
        <Typography variant="body1" color="text.secondary">
          Classic
        </Typography>
      </Box>

      <SocialMediaDisplay section="upper" />
    </UpperContainer>
  );
};
export default UpperSection;
