import styled from "@emotion/styled";
import { MOBILE, TABLET } from "../../utils/styles/constants";

export const UpperContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  margin-bottom: 40px;
  gap: 15px;

  @media (${TABLET}) {
    grid-template-columns: repeat(3, 1fr);
  }

  @media (${MOBILE}) {
    grid-template-columns: 1fr;
    gap: 24px;
    margin-bottom: 24px;
  }
`;

export const Button = styled.button`
  background: none;
  padding-inline: 0;
  border: none;
  text-align: start;
  cursor: pointer;

  &:hover {
    text-decoration: underline;
  }
`;
