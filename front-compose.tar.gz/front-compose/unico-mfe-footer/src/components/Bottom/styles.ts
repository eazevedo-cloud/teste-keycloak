import styled from "@emotion/styled";
import { MOBILE } from "../../utils/styles/constants";

export const BottomContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-top: 24px;

  @media (${MOBILE}) {
    flex-direction: column;

    img {
      align-self: flex-end;
      margin-top: 16px;
    }
  }
`;
