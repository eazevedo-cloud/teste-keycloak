import React from 'react';
import { Typography } from '@unicred/uds-core';
import { BottomContainer } from './styles';

export default function Bottom() {
  return (
    <BottomContainer>
      <Typography variant='body1' color='text.primary' fontWeight='bold'>
        © Todos direitos reservados 2024
      </Typography>
      <img
        src='https://statics-uds-prd.e-unicred.com.br/0.27.0/e7b80bc0434575d3eab72a88f19bbb60/uds-logo-unicred-colorful.svg'
        alt='Logo Unicred'
        height={18}
        width={117}
      />
    </BottomContainer>
  );
}
