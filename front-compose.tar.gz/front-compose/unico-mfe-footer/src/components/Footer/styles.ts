import styled from "@emotion/styled";
import { MOBILE } from "../../utils/styles/constants";

export const Container = styled.footer`
  background-color: #fff;
  padding: 32px 64px;
  color: #333;

  @media (${MOBILE}) {
    padding: 20px;
  }
`;
