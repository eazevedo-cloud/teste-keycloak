import { LowerSection, SocialMediaDisplay, UpperSection, Bottom } from "..";
import { Container } from "./styles";

const Footer = () => {
  return (
    <Container>
      <UpperSection />
      <LowerSection />
      <SocialMediaDisplay section="lower" />
      <Bottom />
    </Container>
  );
};

export default Footer;
