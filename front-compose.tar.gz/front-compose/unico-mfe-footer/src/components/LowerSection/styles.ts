import styled from "@emotion/styled";
import { MOBILE, TABLET } from "../../utils/styles/constants";

export const LowerContainer = styled.div`
  display: grid;
  grid-template-columns: 51.2% 9.6% 1fr;
  gap: 80px;
  margin-bottom: 40px;

  @media (${TABLET}) {
    grid-template-columns: 1fr 1fr;

    & > :first-child {
      grid-column: span 2;
    }
  }

  @media (${MOBILE}) {
    grid-template-columns: 1fr;
    gap: 24px;
    margin-bottom: 24px;

    & > :first-child {
      grid-column: auto;
    }
  }
`;

export const ContactsContainer = styled.div`
  display: flex;
  justify-content: space-between;
  flex-wrap: nowrap;
  gap: 16px;

  @media (${MOBILE}) {
    flex-direction: column;
  }
`;

export const ContactInfo = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;

  @media (${MOBILE}) {
    gap: 4px;
  }
`;
