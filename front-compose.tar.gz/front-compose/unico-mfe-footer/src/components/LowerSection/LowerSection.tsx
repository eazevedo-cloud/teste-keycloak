import React from 'react';
import { ContactInfo, ContactsContainer, LowerContainer } from './styles';
import { Box, Divider, Link, Typography } from '@unicred/uds-core';

export default function LowerSection() {
  return (
    <LowerContainer>
      <Box display='flex' flexDirection='column' gap={1} width='100%'>
        <Box>
          <Typography variant='h2'>
            Central de Relacionamento Unicred Visa
          </Typography>
          <Typography variant='body1' color='text.secondary'>
            24 horas por dia, 7 dias por semana
          </Typography>
        </Box>

        <Divider />

        <ContactsContainer>
          <ContactInfo>
            <Typography variant='body1' color='text.primary'>
              Capitais e regiões metropolitanas
            </Typography>
            <Link href='tel:40071038' color='blue.500' underline='hover'>
              4007 1038
            </Link>
          </ContactInfo>
          <ContactInfo>
            <Typography variant='body1' color='text.primary'>
              Demais localidades
            </Typography>
            <Link href='tel:08006005237' color='blue.500' underline='hover'>
              0800 600 52 37
            </Link>
          </ContactInfo>
          <ContactInfo>
            <Typography variant='body1' color='text.primary'>
              Exterior
            </Typography>
            <Link href='tel:+553140071038' color='blue.500' underline='hover'>
              +55 31 4007-1038
            </Link>
          </ContactInfo>
        </ContactsContainer>
      </Box>

      <Box display='flex' flexDirection='column' gap={1}>
        <Box>
          <Typography variant='h2'>SAC</Typography>
          <Typography variant='body1' color='text.secondary'>
            Das 9h às 18h
          </Typography>
        </Box>

        <Divider />

        <ContactInfo>
          <Typography variant='body1' color='text.primary'>
            Todas regiões
          </Typography>
          <Link href='tel:08006472930' color='blue.500' underline='hover'>
            0800 647 2930
          </Link>
        </ContactInfo>
      </Box>

      <Box display='flex' flexDirection='column' gap={1}>
        <Box>
          <Typography variant='h2'>Ouvidoria</Typography>
          <Typography variant='body1' color='text.secondary'>
            Das 9h às 13h e das 14h às 18h (Dias úteis)
          </Typography>
        </Box>

        <Divider />

        <ContactInfo>
          <Typography variant='body1' color='text.primary'>
            Todas regiões
          </Typography>
          <Link href='tel:08009400602' color='blue.500' underline='hover'>
            0800 940 0602
          </Link>
        </ContactInfo>
      </Box>
    </LowerContainer>
  );
}
