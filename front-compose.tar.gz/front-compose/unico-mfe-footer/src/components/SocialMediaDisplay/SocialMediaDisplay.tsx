import { Box, Icon, IconButton, Link, Typography } from "@unicred/uds-core";
import { SocialMediaDisplayProps } from "./types";
import { IconsContainer } from "./styles";

const SocialMediaDisplay = ({ section }: SocialMediaDisplayProps) => {
  const socialIcons = [
    {
      title: "uds-instagram",
      link: "https://www.instagram.com/unicredbrasil/",
    },
    { title: "uds-facebook", link: "https://www.facebook.com/unicredbrasil/" },
    { title: "uds-twitter", link: "https://twitter.com/unicred_" },
    { title: "uds-youtube", link: "https://www.youtube.com/@unicred" },
    {
      title: "uds-spotify",
      link: "https://open.spotify.com/show/0JFVXPJPe3fW2CzDC7a43I?si=96b5942ee5594879",
    },
    {
      title: "uds-linkedin",
      link: "https://www.linkedin.com/company/unicredbr/mycompany",
    },
  ];

  return (
    <IconsContainer section={section}>
      <Typography variant="n5" fontWeight="bold" color="text.secondary">
        Redes sociais
      </Typography>
      <Box sx={{ display: "flex" }}>
        {socialIcons.map((icon) => (
          <Link
            key={icon.title}
            display="flex"
            padding={1.5}
            href={icon.link}
            target="_blank"
            color="text.primary"
          >
            <IconButton color="inherit">
              <Icon name={icon.title} size="medium" />
            </IconButton>
          </Link>
        ))}
      </Box>
    </IconsContainer>
  );
};

export default SocialMediaDisplay;
