import styled from "@emotion/styled";
import { css } from "@emotion/react";

import { DESKTOP, SMALL } from "../../utils/styles/constants";
import { SocialMediaDisplayProps } from "./types";

export const IconsContainer = styled.div<SocialMediaDisplayProps>`
  display: flex;
  flex-direction: column;
  gap: 15px;

  ${({ section }) => css`
    ${section === "upper" &&
    css`
      display: none;
      @media (${DESKTOP}) {
        display: flex;
      }
    `}

    ${section === "lower" &&
    css`
      @media (${DESKTOP}) {
        display: none;
      }
    `}
  `}

  @media (${SMALL}) {
    a {
      padding: 0;
    }
  }
`;
