export type SocialMediaDisplayProps = {
  section: 'upper' | 'lower';
};