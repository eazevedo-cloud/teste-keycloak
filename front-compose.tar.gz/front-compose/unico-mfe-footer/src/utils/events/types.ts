export interface GoPointsEvent {
  name: string;
  message: string;
  path: string;
}
