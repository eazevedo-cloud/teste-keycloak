import { GoPointsEvent } from "./types";

/**
 * Criação de novo evento para a GoPoins.
 *
 * @param name - O nome do novo evento a ser criado;
 * @param message - A mensagem sobre o novo evento;
 * @param path - O caminho relativo da origem do novo evento;
 */
export function goPointsEvent({ name, message, path }: GoPointsEvent) {
  const event = new CustomEvent(name, {
    detail: {
      message,
      path,
    },
  });

  window.dispatchEvent(event);
}
