import { css } from "@emotion/react";

// Content
const centerX = css`
  position: relative;
  left: 50%;
  -ms-transform: translateX(-50%);
  transform: translateX(-50%);
`;

// FX
const transition = ({ property, duration, timing, delay }: any) => css`
  transition: ${property || "all"} ${duration || "1s"} ${timing || "ease"} ${delay || ""};
`;

export { centerX, transition };
