// Devices
export const DESKTOP: string = "min-width: 1025px";
export const TABLET: string = "max-width: 1024px";
export const MOBILE: string = "max-width: 744px";
export const SMALL: string = "max-width: 540px";
