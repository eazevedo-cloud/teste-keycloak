import { FunctionComponent } from "react";

import { ThemeProvider } from "@unicred/uds-core";
import { Footer } from "./components";

export const UnicoMfeFooterComponent: FunctionComponent = () => {
  return (
    <>
      <ThemeProvider>
        <Footer />
      </ThemeProvider>
    </>
  );
};
