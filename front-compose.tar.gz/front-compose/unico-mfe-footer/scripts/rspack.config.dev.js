import { resolve, dirname } from "path";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
/**
 * Definição das configurações de desenvolvimento.
 *
 * @type {import('@rspack/cli').Configuration}
 */
const confDev = {
  mode: "development",
  devServer: {
    port: 8081,
    static: resolve(__dirname, "public"),
    hot: false,
    open: false,
    historyApiFallback: false,
    allowedHosts: "all",
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    client: {
      webSocketURL: {
        hostname: "localhost",
      },
    },
    server: {
      type: "https",
      options: {
        key: readFileSync(resolve(__dirname, "../localhost-key.pem"), "utf-8"),
        cert: readFileSync(resolve(__dirname, "../localhost.pem"), "utf-8"),
      },
    },
  },
};

export default confDev;
