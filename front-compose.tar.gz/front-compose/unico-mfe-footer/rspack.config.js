import rspack from "@rspack/core";
import { DotenvPlugin } from "rspack-plugin-dotenv";
import path, { resolve } from "path";
import { mergeDeep, projectName } from "./scripts/utils.js";
import externals from "./scripts/rspack.externals.js";

import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export default (env, argv) => {
  const { mode } = argv;
  const isProduction = mode === "production";

  /**
   * @type {import('@rspack/cli').Configuration}
   */
  let config = {
    context: __dirname,
    devServer: {
      port: 8081,
    },
    devtool: isProduction ? false : "source-map",
    stats: "normal",
    entry: { main: "./src/UnicoMfeFooterComponent.tsx" },
    resolve: {
      extensions: ["...", ".ts", ".tsx", ".jsx"],
      tsConfigPath: resolve(__dirname, "tsconfig.json"),
    },
    externals,
    plugins: [
      new rspack.ProgressPlugin({
        prefix: `[${projectName}]`,
      }),
      new DotenvPlugin({ safe: true }),
      new rspack.container.ModuleFederationPlugin({
        name: "unico_mfe_footer",
        filename: "unico_mfe_footer.js",
        exposes: {
          "./UnicoMfeFooterComponent": "./src/UnicoMfeFooterComponent",
        },
        shared: {
          react: {
            singleton: true,
            requiredVersion: "18.3.0",
          },
          "react-dom": {
            singleton: true,
            requiredVersion: "18.3.0",
          },
        },
      }),
    ],
    module: {
      rules: [
        {
          test: /\.svg$/,
          type: "asset",
        },
        {
          test: /\.(jsx?|tsx?)$/,
          use: [
            {
              loader: "builtin:swc-loader",
              options: {
                sourceMap: !isProduction,
                jsc: {
                  parser: {
                    syntax: "typescript",
                    tsx: true,
                  },
                  transform: {
                    react: {
                      runtime: "automatic",
                      development: !isProduction,
                    },
                  },
                },
                env: {
                  targets: [
                    "chrome >= 87",
                    "edge >= 88",
                    "firefox >= 78",
                    "safari >= 14",
                  ],
                },
              },
            },
          ],
        },
      ],
    },
  };

  // Carregamento condicional baseado no ambiente (dev/prd)
  if (!isProduction) {
    import("./scripts/rspack.config.dev.js").then((devConfig) => {
      config = mergeDeep(config, devConfig.default);
    });
  } else {
    import("./scripts/rspack.config.prd.js").then((prdConfig) => {
      config = mergeDeep(config, prdConfig.default);
    });
  }

  return config;
};
