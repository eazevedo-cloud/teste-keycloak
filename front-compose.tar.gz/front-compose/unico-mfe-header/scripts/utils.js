import { readFileSync } from "fs";
import { resolve } from "path";

// Carregar o conteúdo do package.json manualmente
const packageJsonPath = resolve("./package.json");
const packageJson = JSON.parse(readFileSync(packageJsonPath, "utf8"));

/**
 * Nome do projeto normalizado.
 */
const projectName = packageJson.name.replace(/@/g, "").replace(/\//g, "-");

/**
 * Faz o merge de dois objetos de forma recursiva e retorna um novo objeto.
 *
 * @param {*} target
 * @param {*} source
 *
 * @returns {Object}
 */
const mergeDeep = (target, source) => {
  const isObject = (obj) => obj && typeof obj === "object";

  if (!isObject(target) || !isObject(source)) {
    return source;
  }

  Object.keys(source).forEach((key) => {
    const targetValue = target[key];
    const sourceValue = source[key];

    if (Array.isArray(targetValue) && Array.isArray(sourceValue)) {
      target[key] = targetValue.concat(sourceValue);
    } else if (isObject(targetValue) && isObject(sourceValue)) {
      target[key] = mergeDeep(Object.assign({}, targetValue), sourceValue);
    } else {
      target[key] = sourceValue;
    }
  });

  return target;
};

export { mergeDeep, projectName };
