/**
 * Lista de dependências externas (que não serão inclusas no build do projeto)
 */
const externals = [
  // Dependências padrão
  // "@emotion/react",
  // "@emotion/styled",
  // "@mui/material",
  // "react",
  // "react-dom",
  // Dependências: UDS. (Descomentar as linhas abaixo quando o UDS for disponibilizado em tempo de execução!!)
  // "@unicred/uds-core",
  // "@unicred/uds-icons",
  // "@unicred/uds-team-ib",
];

// Exportando o array `externals` com ES6
export default externals;
