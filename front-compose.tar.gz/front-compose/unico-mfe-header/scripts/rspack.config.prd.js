/**
 * Definição das configurações de produção.
 *
 * @type {import('@rspack/cli').Configuration}
 */
const confPrd = {
  mode: "production",
};

export default confPrd;
