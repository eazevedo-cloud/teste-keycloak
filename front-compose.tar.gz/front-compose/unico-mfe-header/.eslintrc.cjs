/**
 * @type {import('eslint').ESLint.ConfigData}
 */
module.exports = {
  root: true,
  env: {
    node: true,
    browser: true,
    jest: true,
  },
  extends: [
    "plugin:react/recommended",
    "eslint:recommended",
    "airbnb",
    "airbnb/hooks",
    "plugin:@typescript-eslint/recommended",
    "airbnb-typescript",
    "plugin:react/jsx-runtime",
  ],
  parser: "@typescript-eslint/parser",
  parserOptions: {
    ecmaFeatures: {
      jsx: true,
    },
    ecmaVersion: "latest",
    sourceType: "module",
    project: "./tsconfig.lint.json",
  },
  plugins: [
    "@typescript-eslint",
    "react",
    "jest-dom",
    "testing-library",
    "import",
    "jest",
  ],
  rules: {
    // Regras de formatação de código
    "@typescript-eslint/no-explicit-any": "off",
    "linebreak-style": ["error", "unix"],
    quotes: ["error", "single"],
    semi: ["error", "always"],
    "react/function-component-definition": [
      "error",
      {
        namedComponents: "arrow-function",
        unnamedComponents: "arrow-function",
      },
    ],
    // Regras desabilitadas
    "@typescript-eslint/naming-convention": "off",
    "import/prefer-default-export": "off",
    "no-nested-ternary": "off",
    "import/prefer-default-export": "off",
    "react/jsx-props-no-spreading": "off",
    "import/no-extraneous-dependencies": ["error", {"devDependencies": true}],
    "import/no-cycle": "off",
    "@typescript-eslint/no-unused-expressions": "off",
    "react-hooks/exhaustive-deps": "warn",
    "react/jsx-no-constructed-context-values": "warn",
  },
  overrides: [
    {
      files: ["**/__tests__/**/*.[jt]s?(x)", "**/?(*.)+(spec|test).[jt]s?(x)"],
      extends: [
        "plugin:jest/all",
        "plugin:jest-dom/recommended",
        "plugin:testing-library/react",
      ],
      rules: {
        "no-explicit-any": "off",
        "jest/no-hooks": "off",
        "jest/prefer-called-with": "off",
        "jest/prefer-strict-equal": "off",
        "jest/prefer-expect-assertions": "off",
        "import/no-extraneous-dependencies": ["off"],
        "jest/max-expects": "off",
        "jest/no-untyped-mock-factory": "off"
      },
      settings: {
        jest: {
          version: require("jest/package.json").version,
        },
      },
    },
  ],
};
