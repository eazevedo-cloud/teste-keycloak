# ⚓ Modelo Microfrontend React

Este projeto representa uma base sólida para a criação de novos microfrontends usando o `single-spa`. A estrutura já vem equipada com ferramentas essenciais para o desenvolvimento, incluindo:

- **Referência React na prática**: [Referência React recomendada](https://dev.azure.com/unicredbr/TI/_wiki/wikis/TI.wiki/14066/Refer%C3%AAncia-React) aplicada;
- **Tecnologias homologadas**: Implementação básica das [ferramentas homologadas](https://dev.azure.com/unicredbr/TI/_wiki/wikis/TI.wiki/10920/Tecnologia) pela iniciativa;
- **Qualidade e consistência**: Regras de ESLint foram ajustadas seguindo o guia de estilo Airbnb, um padrão reconhecido amplamente utilizado na indústria.
- **Formatação aprimorada**: Integração do ESLint e Prettier para garantir uma formatação uniforme do código.
- **Testes unitários otimizados**: Configurações otimizadas e padronizadas para testes, alinhadas com a arquitetura (minimamente **95%** de coverage).
- **Servidor de mocks**: O MSW (Mock Service Worker) foi configurado para simular requisições com eficiência.
- **Git Hooks estratégicos**: Utilização do Husky para executar ações no momento do commit, incluindo:
  - **lint-staged**: Verificações automáticas nos arquivos modificados, cobrindo testes unitários, regras de lint e formatação.
  - **commitlint**: Validação da mensagem de commit seguindo o padrão [Conventional Commits](https://www.conventionalcommits.org/).
- **Build e empacotamento eficientes**: A combinação da velocidade do [Rspack](https://www.rspack.dev/) com uma configuração de build otimizada resulta em uma performance de build superior, aumentando a eficiência **[em mais de 10x](https://www.rspack.dev/misc/benchmark.html)** em comparação com o [webpack](https://webpack.js.org/).

## 🛠️ Personalizações por Projeto

Para usar este modelo, você precisa fazer duas adaptações:

- Nome do microfrontend: No arquivo `package.json`, ajuste o nome do projeto conforme o padrão: `@unicred/app-<seuapp>`;
- Descrição do microfrontend: No arquivo `package.json`, ajuste a descrição do seu projeto;
- Autor do microfrontend: No arquivo `package.json`, ajuste o `author` do projeto, colocando o seu nome, e movendo o nome que ali consta para o array de `contributors`;
- Variáveis de ambiente: No arquivo `.env.example`, insira as variáveis necessárias para o seu projeto e ajuste a `URL_BFF` apontando para o seu BFF;
- Pipeline: Ajustar as linhas 50 e 52 do arquivo de pipeline, ajustando com a URL correta do seu BFF conforme exemplo.

Feitas essas alterações, você estará pronto para começar o desenvolvimento!

## 🚀 Recomendações para sua IDE (VSCode)

Para facilitar a formatação e a padronização do código, instale as extensões:

- [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint): A configuração existente no projeto executará o ESLint a cada "save" dado em um arquivo;
- [EditorConfig](https://marketplace.visualstudio.com/items?itemName=EditorConfig.EditorConfig): O EditorConfig garante a formatação logo ao abrir o arquivo, estando devidamente configurado para não conflitar com as demais configurações e presets de ESLint e Prettier.

## 🎯 Início Rápido

Para configurar e rodar este projeto, siga estas etapas:

1. **Configuração inicial**: No diretório raiz do projeto, crie um arquivo `.env` e preencha as variáveis de ambiente conforme o exemplo em `.env.example`.

2. **Início da jornada**: Para iniciar o projeto, execute os comandos abaixo:

```bash
# Instale as dependências necessárias
pnpm install

# Gere um certificado SSL para segurança
mkcert localhost

# Inicie o projeto
pnpm start
```

Fantástico! Seu projeto está em execução na porta local 8080 (🌐 [https://localhost:8080/](https://localhost:8080/)). Além disso, o arquivo estático gerado pode ser encontrado na pasta `dist`. Acesse-o pelo link https://localhost:8080/unicred-app-seuapp.js

## 🪄 Bônus Adicional

Este projeto também inclui exemplos detalhados de como utilizar:

- O [módulo de assinatura eletrônica](https://dev.azure.com/unicredbr/TI/_wiki/wikis/TI.wiki/14053/Utilit%C3%A1rio-de-Assinatura-Eletr%C3%B4nica)...
- O consumo do BFF, com a utilização poderosa do SWR para gerenciar as requisições...
- Exemplos de listagem simples e a abstração de um componente de tabela...
- Testes unitários e utilitários de mocks para simplificar o desenvolvimento...
- Tipagens e configurações iniciais otimizadas do SWR...
- O uso do [strict mode do React](https://react.dev/reference/react/StrictMode)...
- E muito mais! Aproveite a jornada de desenvolvimento!
