declare global {
  interface Window {
    timerId: any;
  }
}

window.timerId = window.timerId || {};

export {};
