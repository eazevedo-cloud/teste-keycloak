import { FunctionComponent } from 'react';
import { Global } from '@emotion/react';
import { ThemeProvider } from '@unicred/uds-core';

import { Reset } from '@utils/styles/reset';
import { AuthProvider, UserProvider } from 'contexts';
import { Header } from './components';

export const UnicoMfeHeaderComponent: FunctionComponent = () => (
  <ThemeProvider mode="unico">
    <Global styles={Reset} />
    <UserProvider>
      <AuthProvider>
        <Header />
      </AuthProvider>
    </UserProvider>
  </ThemeProvider>
);
