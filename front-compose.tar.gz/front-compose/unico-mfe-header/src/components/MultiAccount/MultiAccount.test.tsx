import { render, screen, fireEvent } from '@testing-library/react';
import { useAuth } from 'contexts';
import MultiAccount from './MultiAccount';
import { AccountLabel } from '..';
import { getInitials } from './actions';

jest.mock('contexts', () => ({
  useAuth: jest.fn(),
}));

jest.mock('@utils/events', () => ({
  goPointsEvent: jest.fn(),
}));

jest.mock('./actions', () => ({
  getInitials: jest.fn((name) => name.charAt(0)),
}));

jest.mock('..', () => ({
  AccountLabel: jest.fn(({ name, document }) => (
    <div>
      {name}
      {' '}
      -
      {' '}
      {document}
    </div>
  )),
}));

describe('multiAccount', () => {
  const setUserInfoMock = jest.fn();
  const fetchBalanceMock = jest.fn();

  const renderComponent = (props = {}) => {
    (useAuth as jest.Mock).mockReturnValue({
      userInfo: {
        name: 'John Doe',
        document: '12345678901',
        accounts: [
          { name: 'Account 1', document: '12345678901' },
          { name: 'Account 2', document: '98765432100' },
        ],
      },
      setUserInfo: setUserInfoMock,
      fetchBalance: fetchBalanceMock,
    });

    return render(<MultiAccount {...props} />);
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render all accounts', () => {
    renderComponent();
    expect(screen.getByText('Account 1 - 12345678901')).toBeInTheDocument();
    expect(screen.getByText('Account 2 - 98765432100')).toBeInTheDocument();
  });

  it('should call setUserInfo and fetchBalance when an account is clicked', async () => {
    renderComponent();
    const accountButton = screen.getByText('Account 2 - 98765432100');
    fireEvent.click(accountButton);

    expect(setUserInfoMock).toHaveBeenCalledWith({
      name: 'Account 2',
      document: '98765432100',
      accounts: expect.any(Array),
    });
    expect(fetchBalanceMock).toHaveBeenCalledWith('98765432100');
  });
});
