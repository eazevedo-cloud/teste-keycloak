import { render, screen } from '@testing-library/react';
import MultiAccountHeader from './MultiAccountHeader';

describe('MultiAccountHeader', () => {
  it('should render the Header with the correct text content', () => {
    render(<MultiAccountHeader />);

    const headerText = screen.getByText('Minhas contas');
    expect(headerText).toBeInTheDocument();
  });
});
