import { useState } from 'react';

import {
  ListItemButton, Typography, Skeleton, Alert,
} from '@unicred/uds-core';
import { UdsSuccessFilled } from '@unicred/uds-icons';

import { Account } from '@interfaces/accessToken';
import { useAuth } from 'contexts';
import { UserInfo } from '@interfaces/user';
import { goPointsEvent } from '@utils/events';
import { MultiAccountProps } from './types';
import { Container } from './styles';
import { getInitials } from './actions';
import { AccountLabel } from '..';

const MultiAccount = ({ show }: MultiAccountProps) => {
  const { userInfo, setUserInfo, fetchBalance } = useAuth();
  const { accounts } = userInfo!;
  const isActiveAccount = (document: string) => document === userInfo!.document;

  let accountsToShow = [];
  let hasScroll: boolean;

  if (show) {
    for (let i = 0; i < show; i++) accountsToShow.push(accounts[i]);
  } else {
    accountsToShow = accounts;
  }

  hasScroll = accountsToShow.length > 6;

  async function handleSelectAccount(account: Account) {
    setUserInfo({
      name: account.name,
      document: account.document,
      accounts: userInfo!.accounts,
    });
    goPointsEvent('unicoSwitchAccount', 'Switch Account', '', {
      name: account.name,
      document: account.document,
    } as UserInfo);
    fetchBalance(account.document);

    // TODO: Atualizar toda a lista de contas após fazer o refresh, para pegar o array de contas atualizado
    // await refreshSession(tokenData.token);
  }

  return (
    <Container
      aria-label="contas do usuário"
      className={hasScroll ? 'scroll' : ''}
    >
      {accountsToShow.map((account, i) => (
        <li
          key={account.document}
          aria-label={`conta ${i + 1} - ${account.name}`}
          className={isActiveAccount(account.document) ? 'active' : ''}
        >
          <ListItemButton
            title={account.name}
            onClick={() => handleSelectAccount(account)}
          >
            <account-avatar aria-label="avatar da conta">
              <Typography variant="body1" aria-label="iniciais da conta">
                {getInitials(account.name)}
              </Typography>
            </account-avatar>

            <account-info aria-label="ionformações da conta">
              <AccountLabel name={account.name} document={account.document} />
            </account-info>

            {isActiveAccount(account.document) && (
            <UdsSuccessFilled color="primary" />
            )}
          </ListItemButton>
        </li>
      ))}
    </Container>
  );
};

export default MultiAccount;
