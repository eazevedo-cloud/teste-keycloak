import { render, screen } from '@testing-library/react';
import MultiAccountBackButton from './MultiAccountBackButton';

describe('MultiAccountBackButton', () => {
  it('should render the MenuItem with the correct title and aria-labels', () => {
    render(<MultiAccountBackButton />);

    const menuItem = screen.getByRole('button', { name: 'voltar ao menu' });
    expect(menuItem).toBeInTheDocument();

    const iconChevronLeft = screen.getByRole('img', { name: 'ícone direcional esquerda' });
    expect(iconChevronLeft).toBeInTheDocument();

    const listItemText = screen.getByLabelText('voltar');
    expect(listItemText).toBeInTheDocument();
  });

  it('should have correct text content', () => {
    render(<MultiAccountBackButton />);
    expect(screen.getByText('Voltar')).toBeInTheDocument();
  });
});
