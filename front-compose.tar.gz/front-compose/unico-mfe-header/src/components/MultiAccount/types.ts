export type MultiAccountProps = {
  show?: number;
};
