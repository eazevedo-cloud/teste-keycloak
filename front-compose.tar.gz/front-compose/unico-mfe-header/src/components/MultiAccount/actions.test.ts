import { getInitials } from './actions';

describe('getInitials', () => {
  it('should return the correct initials for a full name', () => {
    const name = 'João da Silva';
    const result = getInitials(name);
    expect(result).toBe('JS');
  });

  it('should return the correct initials for a single name', () => {
    const name = 'Maria';
    const result = getInitials(name);
    expect(result).toBe('M');
  });

  it('should return the correct initials for a name with multiple parts', () => {
    const name = 'Luís Fernando de Almeida';
    const result = getInitials(name);
    expect(result).toBe('LF');
  });

  it('should return an empty string if no uppercase letter is found', () => {
    const name = 'joão da silva';
    const result = getInitials(name);
    expect(result).toBe('');
  });

  it('should return only two initials even if the name has more than two parts', () => {
    const name = 'Carlos Alberto da Costa Pereira';
    const result = getInitials(name);
    expect(result).toBe('CA');
  });
});
