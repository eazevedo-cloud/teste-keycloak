import { Typography } from '@unicred/uds-core';
import { Header } from './styles';

const MultiAccountHeader = () => {
  return (
    <Header>
      <Typography variant="body1" color="text.disabled">
        Minhas contas
      </Typography>
    </Header>
  );
};

export default MultiAccountHeader;
