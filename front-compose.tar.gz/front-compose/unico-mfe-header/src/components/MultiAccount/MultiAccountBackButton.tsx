import { MenuItem, ListItemIcon, ListItemText } from '@unicred/uds-core';
import { UdsChevronLeft } from '@unicred/uds-icons';

const MultiAccountBackButton = () => {
  return (
    <MenuItem title="Voltar ao menu" role="button" aria-label="voltar ao menu">
      <ListItemIcon role="img" aria-label="ícone direcional esquerda">
        <UdsChevronLeft />
      </ListItemIcon>
      <ListItemText aria-label="voltar">Voltar</ListItemText>
    </MenuItem>
  );
};

export default MultiAccountBackButton;
