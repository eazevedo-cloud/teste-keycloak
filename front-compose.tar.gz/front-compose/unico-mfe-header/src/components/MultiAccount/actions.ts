export function getInitials(name: string) {
  const teste = name.split(" ");
  let initials = "";

  teste.forEach((word) => {
    const initial = word.match(/^[A-Z]/g);
    initial ? (initials.length === 2 ? "" : (initials += initial[0])) : "";
  });

  return initials;
}
