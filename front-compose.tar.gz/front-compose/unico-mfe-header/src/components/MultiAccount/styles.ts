import styled from "@emotion/styled";
import { DESKTOP } from "@utils/styles/constants";

export const Header = styled.header`
  height: 48px;
  padding: 12px 20px 2px 20px;
`;

export const Container = styled.ul`
  padding: 8px;
  display: flex;
  flex-direction: column;
  gap: 8px;

  li {
    min-height: 60px;

    &.active {
      pointer-events: none;
    }

    > div {
      min-height: 60px;
      padding-inline: 10px 15px;

      svg {
        margin-left: auto;
      }
    }

    // Skelleton
    > span {
      width: 310px;
      height: 100%;
      margin: 0 auto;
      transform: translate(0);
    }

    // Error alert
    > .MuiAlert-root {
      width: 310px;
      margin: 0 auto;
      padding-inline: 15px;
      align-items: center;

      .MuiAlert-message {
        overflow: hidden;
      }
    }
  }

  &.scroll {
    height: 416px;
    overflow-y: scroll;
  }

  account-avatar {
    background-color: #bdbdbd;
    width: 40px;
    aspect-ratio: 1;
    margin-right: 15px;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
  }

  account-info {
    width: 230px;
    padding-top: 1px;

    div {
      height: 100%;
    }
  }

  @media (${DESKTOP}) {
    account-name {
      p {
        width: 210px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
  }
`;
