import { render, screen } from '@testing-library/react';
import MultiAccountAllButton from './MultiAccountAllButton';

describe('MultiAccountAllButton', () => {
  it('should render the MenuItem with the correct title and aria-labels', () => {
    render(<MultiAccountAllButton />);

    const menuItem = screen.getByRole('button', { name: 'botão mostrar todas as contas' });
    expect(menuItem).toBeInTheDocument();

    const iconUsers = screen.getByRole('img', { name: 'icone contas múltiplas' });
    expect(iconUsers).toBeInTheDocument();

    const listItemText = screen.getByLabelText('mostrar todas as contas');
    expect(listItemText).toBeInTheDocument();

    const iconChevronRight = screen.getByRole('img', { name: 'icone direcional direita' });
    expect(iconChevronRight).toBeInTheDocument();
  });

  it('should have correct text content', () => {
    render(<MultiAccountAllButton />);
    expect(screen.getByText('Mostrar todas as contas')).toBeInTheDocument();
  });
});
