import { MenuItem, ListItemIcon, ListItemText } from '@unicred/uds-core';
import { UdsUsers, UdsChevronRight } from '@unicred/uds-icons';

const MultiAccountAllButton = () => {
  return (
    <MenuItem
      title="Mostrar todas as contas"
      role="button"
      aria-label="botão mostrar todas as contas"
    >
      <ListItemIcon role="img" aria-label="icone contas múltiplas">
        <UdsUsers />
      </ListItemIcon>
      <ListItemText aria-label="mostrar todas as contas">
        Mostrar todas as contas
      </ListItemText>
      <ListItemIcon role="img" aria-label="icone direcional direita">
        <UdsChevronRight />
      </ListItemIcon>
    </MenuItem>
  );
};

export default MultiAccountAllButton;
