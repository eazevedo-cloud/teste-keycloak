import { render, screen } from '@testing-library/react';
import AccountLabel from './AccountLabel';

describe('accountLabel', () => {
  it('should render the account name with prefix', () => {
    render(
      <AccountLabel prefix="Olá," name="John Doe" document="12345678901" />,
    );

    expect(screen.getByLabelText('nome da conta')).toHaveTextContent('Olá,John Doe');
  });

  it('should render the account name without prefix', () => {
    render(
      <AccountLabel name="John Doe" document="12345678901" />,
    );

    expect(screen.getByLabelText('nome da conta')).toHaveTextContent('John Doe');
  });

  it('should render "Conta pessoal" if the document is a valid CPF', () => {
    render(<AccountLabel name="John Doe" document="44547131031" />);

    expect(screen.getByLabelText('documento da conta')).toHaveTextContent('Conta pessoal');
  });

  it('should render CNPJ formatted when document received is a valid CNPJ', () => {
    render(<AccountLabel name="SpaceX Ltda" document="95661015000107" />);

    expect(screen.getByLabelText('documento da conta')).toHaveTextContent('95.661.015/0001-07');
  });
});
