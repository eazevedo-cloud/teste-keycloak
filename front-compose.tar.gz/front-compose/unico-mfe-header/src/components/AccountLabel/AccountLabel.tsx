import { Typography } from '@unicred/uds-core';

import { validateCPF } from '@utils/form';
import { UserLabelProps } from './types';
import { Container } from './styles';

const AccountLabel = ({ prefix, name, document }: UserLabelProps) => {
  const CNPJMask = (document: string) => document.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');

  return (
    <Container>
      <account-name aria-label="nome da conta">
        <Typography variant="body1">
          {prefix && <span>{prefix}</span>}
          <strong>{name}</strong>
        </Typography>
      </account-name>
      <account-document aria-label="documento da conta">
        <Typography variant="body2" color="text.secondary">
          {validateCPF(document) ? 'Conta pessoal' : CNPJMask(document)}
        </Typography>
      </account-document>
    </Container>
  );
};

export default AccountLabel;
