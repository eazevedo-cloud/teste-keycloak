import styled from "@emotion/styled";

export const Container = styled.div`
  height: 100%;
  text-align: left;

  account-name {
    margin-bottom: 2px;
    display: block;

    p {
      line-height: 17px;
      span {
        margin-right: 3px;
      }
    }
  }

  account-document {
    display: block;
    p {
      line-height: 17px;
    }
  }
`;
