export type UserLabelProps = {
  prefix?: string;
  name: string;
  document: string;
};
