import { IconButton, Typography } from '@unicred/uds-core';
import { UdsClose } from '@unicred/uds-icons';

import { DrawerHeaderProps } from './types';

const DrawerHeader = ({ title, close }: DrawerHeaderProps) => {
  return (
    <header>
      <Typography variant="body2" color="text.disabled">
        {title || 'Drawer Title'}
      </Typography>
      <IconButton
        className="drawer-close-button"
        aria-label="fechar menu"
        title="Fechar"
        onClick={() => close && close(false)}
      >
        <UdsClose />
      </IconButton>
    </header>
  );
};

export default DrawerHeader;
