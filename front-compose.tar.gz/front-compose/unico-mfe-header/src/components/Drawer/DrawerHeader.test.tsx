import { render, screen, fireEvent } from '@testing-library/react';
import DrawerHeader from './DrawerHeader';
import { DrawerHeaderProps } from './types';

const renderComponent = (props: Partial<DrawerHeaderProps> = {}) => {
  const defaultProps: DrawerHeaderProps = {
    title: 'Default Title',
    close: jest.fn(),
    ...props,
  };

  return render(<DrawerHeader {...defaultProps} />);
};

describe('DrawerHeader', () => {
  it('should render with default title when no title is provided', () => {
    renderComponent({ title: undefined });
    expect(screen.getByText('Drawer Title')).toBeInTheDocument();
  });

  it('should render with provided title', () => {
    renderComponent({ title: 'Custom Title' });
    expect(screen.getByText('Custom Title')).toBeInTheDocument();
  });

  it('should call close function when close button is clicked', () => {
    const mockClose = jest.fn();
    renderComponent({ close: mockClose });
    const closeButton = screen.getByLabelText('fechar menu');
    fireEvent.click(closeButton);
    expect(mockClose).toHaveBeenCalledWith(false);
  });

  it('should not throw an error if close function is not provided', () => {
    renderComponent({ close: undefined });
    const closeButton = screen.getByLabelText('fechar menu');
    fireEvent.click(closeButton);
    expect(screen.getByLabelText('fechar menu')).toBeInTheDocument();
  });
});
