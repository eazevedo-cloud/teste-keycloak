let drawer: HTMLElement[] | undefined;
let animation = 375;

export function init() {
  drawer = Array.from(document.querySelectorAll("unico-drawer"));

  if (drawer) {
    setTimeout(() => {
      drawer!.forEach((d) => {
        const tabs = Array.from(
          d.querySelectorAll("drawer-tab"),
        ) as HTMLElement[];
        const hasTabs = tabs && tabs.length > 0;

        if (hasTabs) {
          tabs.forEach((tab, i) => {
            setPosition(tab, i);
            setNavigation(tab);
          });
        }
      });
    }, 500);
  }
}

function setPosition(tab: HTMLElement, i: number) {
  tab.setAttribute("index", `${i}`);
  tab.style.left = `${animation * i}px`;
}

function setNavigation(tab: HTMLElement) {
  const nextButton = tab.querySelector("drawer-next-button");
  const prevButton = tab.querySelector("drawer-prev-button");

  nextButton &&
    nextButton.addEventListener("click", ({ target }) => {
      nav(target!, "next");
      toggleActive(nextButton);
    });

  prevButton &&
    prevButton.addEventListener("click", ({ target }) => {
      nav(target!, "prev");
      toggleActive(prevButton);
    });
}

function toggleActive(target: Element) {
  target.classList.add("active");
  setTimeout(() => {
    target.classList.remove("active");
  }, 500);
}

function nav(target: EventTarget, d: "next" | "prev") {
  const direction = d === "next" ? "-" : "+";
  const thisTabs = (target as HTMLElement)
    .closest("unico-drawer")
    ?.querySelectorAll("drawer-tab");

  if (thisTabs) {
    thisTabs.forEach((t) => {
      const tab = t as HTMLElement;
      const prevLeft = tab.style.left;

      tab.style.left = `calc(${prevLeft} ${direction} ${animation / drawer!.length}px)`;
    });
  }
}

export function closeOtherDrawers() {
  const closeButtons = Array.from(
    document.querySelectorAll(".drawer-close-button"),
  ) as HTMLElement[];

  closeButtons.forEach((btn, i) => {
    const thisDrawer = drawer![i] as HTMLElement;

    if (thisDrawer.classList.contains("open")) {
      const tabs = Array.from(
        thisDrawer.querySelectorAll("drawer-tab"),
      ) as HTMLElement[];
      const hasTabs = tabs && tabs.length > 0;

      btn.click();

      if (hasTabs) {
        setTimeout(() => {
          tabs.forEach((tab, i) => (tab.style.left = `${animation * i}px`));
        }, 500);
      }
    }
  });
}
