import styled from '@emotion/styled';

import {
  DESKTOP,
  EASE,
  HOVER,
  SMALL,
  TABLET,
} from '@utils/styles/constants';
import { DrawerProps } from './types';

export const Container = styled.div<DrawerProps>`
  background-color: #fff;
  width: 0;
  height: 100%;
  overflow: hidden;
  -webkit-box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.6);
  -moz-box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.6);
  box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.6);
  transition: width 0.5s ${EASE};
  position: fixed;
  top: 0;
  right: ${(props) => (props.left ? '' : '0')};
  left: ${(props) => (props.left ? '0' : '')};
  z-index: 11;

  &.open {
    width: 375px;

    > * {
      opacity: 1;
      transition:
        opacity 0.5s 0.3s,
        left 0.5s ${EASE};
    }
  }

  > * {
    opacity: 0;
    transition:
      opacity 0.3s,
      left 0.5s ${EASE};
  }

  header {
    height: 68px;
    padding: 8px 18px 8px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  ul {
    padding: 8px;

    &.scroll {
      height: auto;
      overflow-y: hidden;
    }
  }

  drawer-tab {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    display: block;

    drawer-wrapper {
      height: calc(100% - 68px);
      overflow-y: auto;
      display: block;
    }
  }

  drawer-next-button,
  drawer-prev-button {
    padding-inline: 8px;
    display: block;

    &.active {
      pointer-events: none;
    }

    li {
      height: 48px;
      padding-inline: 10px;
      transition: background-color 0.2s;

      &:hover {
        background-color: ${HOVER};
      }

      > div:nth-child(3) {
        min-width: 24px;
      }
    }

    hr {
      margin-bottom: 0 !important;
    }
  }

  drawer-prev-button {
    height: 68px;
    padding-top: 8px;

    li {
      height: 52px;
      padding-bottom: 8px;
    }
  }

  @media (${SMALL}) {
    &.open {
      width: 83%;
    }
  }

  @media (${TABLET}) {
    display: ${(props) => (props.desktop ? 'none' : '')};
  }

  @media (${DESKTOP}) {
    display: ${(props) => (props.mobile ? 'none' : '')};
  }
`;
