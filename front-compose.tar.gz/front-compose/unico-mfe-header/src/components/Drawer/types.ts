export type DrawerProps = React.ComponentProps<"div"> & {
  variant: "navigation" | "user";
  open?: boolean;
  close?: React.Dispatch<React.SetStateAction<boolean>>;
  desktop?: boolean;
  mobile?: boolean;
  left?: boolean;
};

export type DrawerHeaderProps = {
  title?: string;
  close?: React.Dispatch<React.SetStateAction<boolean>>;
};
