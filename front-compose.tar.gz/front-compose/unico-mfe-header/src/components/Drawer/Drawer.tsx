import { useEffect } from 'react';

import { Divider } from '@unicred/uds-core';

import { Account } from '@interfaces/accessToken';
import { useAuth } from 'contexts';
import { Container } from './styles';
import { DrawerProps } from './types';
import { UnicoDrawer } from './web.comp';
import { init } from './actions';
import DrawerHeader from './DrawerHeader';
import { MenuList, MultiAccount } from '..';
import { MultiAccountAllButton, MultiAccountBackButton } from '../MultiAccount';

customElements.define('unico-drawer', UnicoDrawer);

const Drawer = ({
  variant, open, close, ...props
}: DrawerProps) => {
  const { userInfo } = useAuth();
  const accounts: Account[] | null = userInfo && userInfo!.accounts;
  const quantity = accounts && accounts.length;

  useEffect(() => {
    init();
  }, []);

  return (
    <Container
      variant={variant}
      className={open ? 'open' : ''}
      role="menu"
      aria-label="menu lateral"
      as="unico-drawer"
      {...props}
    >
      {variant === 'user' ? (
        <>
          {quantity && quantity > 1 ? (
            <>
              <drawer-tab>
                <DrawerHeader title="Minhas contas" close={close} />

                <drawer-wrapper>
                  <MultiAccount show={2} />

                  {quantity > 2 ? (
                    <drawer-next-button>
                      <MultiAccountAllButton />
                      <Divider />
                    </drawer-next-button>
                  ) : (
                    <Divider />
                  )}

                  <MenuList variant={variant} close={close} />
                </drawer-wrapper>
              </drawer-tab>

              {quantity > 2 && (
                <drawer-tab>
                  <drawer-prev-button>
                    <MultiAccountBackButton />
                    <Divider />
                  </drawer-prev-button>

                  <drawer-wrapper>
                    <MultiAccount />
                  </drawer-wrapper>
                </drawer-tab>
              )}
            </>
          ) : (
            <>
              <DrawerHeader title="Minha conta" close={close} />
              <MenuList variant={variant} close={close} />
            </>
          )}
        </>
      ) : (
        <>
          <DrawerHeader title="Menu de opções" close={close} />
          <MenuList variant={variant} close={close} />
        </>
      )}
    </Container>
  );
};

export default Drawer;
