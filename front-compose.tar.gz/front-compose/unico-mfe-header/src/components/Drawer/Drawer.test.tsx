import { render, screen, fireEvent } from '@testing-library/react';
import Drawer from './Drawer';
import { SessionContext } from 'contexts';
import { init } from './actions';
import DrawerHeader from './DrawerHeader';
import { MenuList, MultiAccount } from '..';
import { MultiAccountAllButton, MultiAccountBackButton } from '../MultiAccount';
import { Account } from '@interfaces/accessToken';
import { ReactNode } from 'react';
import { SessionContextType } from 'contexts/session/SessionContext';
import { UserInfo } from '@interfaces/user';
import { DrawerProps } from './types';

jest.mock('./actions', () => ({
  init: jest.fn(),
}));

jest.mock('..', () => ({
  MenuList: jest.fn(() => <div aria-label="opções do menu">Mocked MenuList</div>),
  MultiAccount: jest.fn(() => <div>Mocked MultiAccount</div>),
}));

jest.mock('../MultiAccount', () => ({
  MultiAccountAllButton: jest.fn(() => <div>Mocked MultiAccountAllButton</div>),
  MultiAccountBackButton: jest.fn(() => <div>Mocked MultiAccountBackButton</div>),
}));

const closeDrawerMock = jest.fn();

type RenderComponentProps = {
  userInfoOverrides?: Partial<UserInfo>,
  variantOverrides?: DrawerProps["variant"]
}

const renderComponent = ({userInfoOverrides, variantOverrides = "user"}: RenderComponentProps = {}) => {
  const defaultAuthContext: SessionContextType = {
    tokenData: null,
    userInfo: {
      name: "Jane Doe",
      document: '31724704079',
      accounts: [
        { name: 'Account 1', document: '31724704079' },
        { name: 'Account 2', document: '32170248005' },
      ],
      ...userInfoOverrides
    },
    points: '',
    hasSessionExpired: false,
    isLoadingBalance: false,
    errorToFetchBalance: false,
    fetchBalance: jest.fn(),
    saveTokenData: jest.fn(),
    setUserInfo: jest.fn(),
    setPoints: jest.fn(),
    logout: jest.fn(),
  };

  return render(
    <SessionContext.Provider value={defaultAuthContext}>
      <Drawer variant={variantOverrides} open={true} close={closeDrawerMock} />
    </SessionContext.Provider>
  );
};

describe('Drawer', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should call init on mount', () => {
    renderComponent();
    expect(init).toHaveBeenCalled();
  });

  it('should render DrawerHeader with "Minhas contas" when variant is "user" and multiple accounts are present', () => {
    renderComponent();
    expect(screen.getByText('Minhas contas')).toBeInTheDocument();
  });

  it('should render MultiAccount when multiple accounts are present', () => {
    renderComponent();
    expect(screen.getByText('Mocked MultiAccount')).toBeInTheDocument();
  });

  it('should render MultiAccountAllButton when more than two accounts are present', () => {
    const userInfoOverrides = {
      accounts: [
        { name: 'Account 1', document: '12345678901' },
        { name: 'Account 2', document: '98765432100' },
        { name: 'Account 3', document: '11223344556' },
      ],
    };

    renderComponent({ userInfoOverrides });
    expect(screen.getByText('Mocked MultiAccountAllButton')).toBeInTheDocument();
  });

  it('should render "Minha conta" when only one account is present', () => {
    const userInfoOverrides = {
      accounts: [
        { name: 'Account 1', document: '12345678901' },
      ],
    };

    renderComponent({ userInfoOverrides });
    expect(screen.getByText('Minha conta')).toBeInTheDocument();
  });

  it('should render MenuList with correct variant', () => {
    renderComponent();
    expect(screen.getByText('Mocked MenuList')).toBeInTheDocument();
    expect(screen.getByLabelText('opções do menu')).toBeInTheDocument();
  });

  it('should render DrawerHeader with "Menu de opções" when variant is "navigation"', () => {
    renderComponent({ variantOverrides: "navigation" });

    expect(screen.getByText('Menu de opções')).toBeInTheDocument();
    expect(screen.getByLabelText('opções do menu')).toBeInTheDocument();
  });

  it('should render MultiAccountBackButton when more than two accounts are present and in the second tab', () => {
    const userInfoOverrides = {
      accounts: [
        { name: 'Account 1', document: '12345678901' },
        { name: 'Account 2', document: '98765432100' },
        { name: 'Account 3', document: '11223344556' },
      ],
    };

    renderComponent({ userInfoOverrides });
    expect(screen.getByText('Mocked MultiAccountBackButton')).toBeInTheDocument();
  });

  it('should close the drawer when close button is clicked', () => {
    renderComponent();

    const closeButton = screen.getByLabelText('fechar menu');
    fireEvent.click(closeButton);
    expect(closeDrawerMock).toHaveBeenCalledWith(false);
  });
});
