import { init, closeOtherDrawers } from './actions';

jest.useFakeTimers();

describe('Drawer Actions', () => {
  let mockDrawer: HTMLElement;
  let mockTabs: HTMLElement[];
  let mockCloseButton: HTMLElement;

  beforeEach(() => {
    document.body.innerHTML = `
      <div class="drawer-close-button"></div>
      <unico-drawer class="open">
        <drawer-tab></drawer-tab>
        <drawer-tab></drawer-tab>
      </unico-drawer>
    `;

    mockDrawer = document.querySelector('unico-drawer')!;
    mockTabs = Array.from(mockDrawer.querySelectorAll('drawer-tab'));
    mockCloseButton = document.querySelector('.drawer-close-button')!;
    jest.spyOn(mockCloseButton, 'click').mockImplementation(() => {
      mockDrawer.classList.remove('open');
    });
  });

  afterEach(() => {
    jest.clearAllTimers();
    jest.restoreAllMocks();
  });

  describe('init', () => {
    it('should initialize the drawer with tabs and set position and navigation', () => {
      init();
      jest.advanceTimersByTime(500);

      expect(mockTabs.length).toBeGreaterThan(0);
      mockTabs.forEach((tab, index) => {
        expect((tab as HTMLElement).style.left).toBe(`${index * 375}px`);
      });
    });
  });

  describe('closeOtherDrawers', () => {
    it('should close open drawers and reset tab positions', () => {
      mockDrawer.classList.add('open');

      closeOtherDrawers();
      jest.advanceTimersByTime(500);

      expect(mockDrawer.classList.contains('open')).toBe(false);
    });
  });
});
