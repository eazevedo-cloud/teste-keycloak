import styled from '@emotion/styled';
import { HOVER } from '@utils/styles/constants';

export const Container = styled.ul`
  li {
    height: 48px;
    padding-inline: 8px;
    transition: background-color 0.2s;

    &:hover {
      background-color: ${HOVER};
    }

    &.active {
      pointer-events: none;
    }
  }
`;
