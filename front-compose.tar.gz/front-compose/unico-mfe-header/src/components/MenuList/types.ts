export type ItemProps = {
  variant: 'navigation' | 'user';
  close?: React.Dispatch<React.SetStateAction<boolean>>;
};
