import { render, screen, fireEvent } from '@testing-library/react';
import { useAuth, useUserContext } from 'contexts';
import { goPointsEvent } from '@utils/events';
import { MENU_LINKS_MAP } from '@utils/data/menuLinks';
import MenuList from './MenuList';
import { ItemProps } from './types';

jest.mock('contexts', () => ({
  useAuth: jest.fn(),
  useUserContext: jest.fn(),
}));

jest.mock('@utils/events', () => ({
  goPointsEvent: jest.fn(),
}));

describe('menuList', () => {
  const logoutMock = jest.fn();

  const renderComponent = (props: Partial<ItemProps> = {}) => {
    const defaultProps: ItemProps = {
      variant: 'user',
      close: jest.fn(),
      ...props,
    };

    (useAuth as jest.Mock).mockReturnValue({
      userInfo: {
        name: 'John Doe',
        document: '12345678901',
      },
      logout: logoutMock,
    });

    (useUserContext as jest.Mock).mockReturnValue({
      isActive: jest.fn().mockReturnValue(true),
    });

    return render(<MenuList {...defaultProps} />);
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render all user menu items', () => {
    renderComponent();
    expect(screen.getByText('Extrato')).toBeInTheDocument();
    expect(screen.getByText('Meus pedidos')).toBeInTheDocument();
    expect(screen.getByText('Meus endereços')).toBeInTheDocument();
    expect(screen.getByText('Sair')).toBeInTheDocument();
  });

  it('should call goPointsEvent when a menu item (except logout) is clicked', () => {
    renderComponent();
    const menuItem = screen.getByText('Extrato');
    fireEvent.click(menuItem);
    expect(goPointsEvent).toHaveBeenCalledWith(
      'unicoURLValid',
      'Extrato',
      MENU_LINKS_MAP?.EXTRATO,
      expect.any(Object),
    );
  });

  it('should call logout when logout menu item is clicked', () => {
    renderComponent();
    const logoutItem = screen.getByText('Sair');
    fireEvent.click(logoutItem);
    expect(logoutMock).toHaveBeenCalled();
  });

  it('should close the menu when a menu item is clicked', () => {
    const mockClose = jest.fn();
    renderComponent({ close: mockClose });
    const menuItem = screen.getByText('Extrato');
    fireEvent.click(menuItem);
    expect(mockClose).toHaveBeenCalledWith(false);
  });

  it('should render navigation menu items when variant is "navigation"', () => {
    renderComponent({ variant: 'navigation' });
    expect(screen.getByText('Shopping')).toBeInTheDocument();
    expect(screen.getByText('Produtos Unicred')).toBeInTheDocument();
    expect(screen.getByText('Transferir pontos')).toBeInTheDocument();
  });
});
