import { Fragment } from 'react';

import {
  Divider,
  MenuItem,
  ListItemIcon,
  ListItemText,
} from '@unicred/uds-core';
import {
  UdsCarshopCheck,
  UdsExtract,
  UdsExit,
  UdsLocation,
  UdsHandbag,
  UdsTransfer,
  UdsReward,
} from '@unicred/uds-icons';

import { goPointsEvent } from '@utils/events';
import { MENU_LINKS_MAP } from '@utils/data/menuLinks';
import { useUserContext } from 'contexts';
import { useAuth } from '../../contexts';
import { ItemProps } from './types';
import { Container } from './styles';

const MenuList = ({ variant, close }: ItemProps) => {
  const { logout, userInfo } = useAuth();
  const { isActive } = useUserContext();

  const options = {
    navigation: [
      {
        text: 'Shopping',
        icon: <UdsHandbag />,
        action: () => {
          goPointsEvent(
            'unicoURLValid',
            'Shopping',
            MENU_LINKS_MAP?.SHOPPING,
            userInfo,
          );
        },
      },
      {
        text: 'Produtos Unicred',
        icon: <UdsReward />,
        action: () => {
          goPointsEvent(
            'unicoURLValid',
            'Produtos Unicred',
            MENU_LINKS_MAP?.PRODUTOS_UNICRED,
            userInfo,
          );
        },
      },
      {
        text: 'Transferir pontos',
        icon: <UdsTransfer />,
        action: () => {
          goPointsEvent(
            'unicoURLValid',
            'Transferir pontos',
            MENU_LINKS_MAP?.TRANSFERIR_PONTOS,
            userInfo,
          );
        },
      },
    ],
    user: [
      {
        text: 'Extrato',
        icon: <UdsExtract />,
        action: () => {
          goPointsEvent(
            'unicoURLValid',
            'Extrato',
            MENU_LINKS_MAP?.EXTRATO,
            userInfo,
          );
        },
      },
      {
        text: 'Meus pedidos',
        icon: <UdsCarshopCheck />,
        action: () => {
          goPointsEvent(
            'unicoURLValid',
            'Meus pedidos',
            MENU_LINKS_MAP?.MEUS_PEDIDOS,
            userInfo,
          );
        },
      },
      {
        text: 'Meus endereços',
        icon: <UdsLocation />,
        action: () => {
          goPointsEvent(
            'unicoURLValid',
            'Meus endereços',
            MENU_LINKS_MAP?.MEUS_ENDERECOS,
            userInfo,
          );
        },
      },
      {
        text: 'Sair',
        icon: <UdsExit />,
        action: logout,
      },
    ],
  };

  const items = options[variant];
  const hasDivider = variant === 'user';
  const isLastItem = (i: number) => i === items.length - 1;

  return (
    <Container aria-label="opções do menu">
      {items.map((item, i) => (
        // eslint-disable-next-line react/no-array-index-key
        <Fragment key={i}>
          {isLastItem(i) && hasDivider && <Divider />}
          <MenuItem
            className={isActive(item.text) ? 'active' : ''}
            onClick={() => {
              if (close) close(false);
              item.action();
            }}
            title={item.text}
            aria-label={`opção ${i + 1}: ${item.text}`}
          >
            <ListItemIcon
              role="img"
              aria-label={`icone ${item.text}`}
              sx={{
                color: (theme: any) => (isActive(item.text) ? theme.palette.primary.main : ''),
              }}
            >
              {item.icon}
            </ListItemIcon>
            <ListItemText
              aria-label={`texto ${item.text}`}
              sx={{
                color: (theme: any) => (isActive(item.text) ? theme.palette.primary.main : ''),
              }}
            >
              {item.text}
            </ListItemText>
          </MenuItem>
        </Fragment>
      ))}
    </Container>
  );
};

export default MenuList;
