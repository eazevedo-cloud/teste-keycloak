export class UnicoLogo extends HTMLElement {
  static get observedAttributes() {
    return ['classname'];
  }

  attributeChangedCallback(name: string, oldValue: string, newValue: string) {
    this.setAttribute('class', newValue);
  }
}
