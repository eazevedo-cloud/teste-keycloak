export type LogoProps = {
  width?: string;
  height?: string;
  variant?: 'N';
  color?: string;
  href?: string;
};
