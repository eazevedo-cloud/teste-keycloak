import { useState } from 'react';

import { Link } from '@unicred/uds-core';

import { Container, Img } from './styles';
import { LogoProps } from './types';
import { UnicoLogo } from './web.comp';

customElements.define('unico-logo', UnicoLogo);

const Logo = ({
  variant, width, height, href,
}: LogoProps) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <Container
      width={width}
      height={height}
      variant={variant}
      role="img"
      aria-label="logo canal único"
      as="unico-logo"
    >
      <Link
        href={href || undefined}
        height="100%"
        display={loaded ? 'block' : 'none'}
        className={href ? undefined : 'disabled'}
      >
        <Img
          src={
              variant
                ? 'https://statics-uds-prd.e-unicred.com.br/0.26.0/434abc896105e5f9754bf9366c7edf42/uds-logo-unico-white.svg'
                : 'https://statics-uds-prd.e-unicred.com.br/0.26.0/434abc896105e5f9754bf9366c7edf42/uds-logo-unico.svg'
            }
          onLoad={() => setLoaded(true)}
          width={width}
          height={height}
          alt="Logo Único"
        />
      </Link>
    </Container>
  );
};

export default Logo;
