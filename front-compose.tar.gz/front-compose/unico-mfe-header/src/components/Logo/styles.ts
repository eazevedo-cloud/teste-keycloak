import styled from '@emotion/styled';

import { transition } from '@utils/styles/mixins';
import { LogoProps } from './types';

export const Container = styled.div<LogoProps>`
  width: ${(props) => (props.width ? props.width : props.variant ? '30px' : '80px')};
  height: ${(props) => (props.height ? props.height : '20px')};
  display: block;
  position: relative;
  left: 0;

  ${transition};

  .disabled:hover {
    cursor: default;
  }
`;

export const Img = styled.img`
  width: 100%;
  height: 100%;
`;
