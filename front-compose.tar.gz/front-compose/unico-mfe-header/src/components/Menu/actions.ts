import { EASE } from '@utils/styles/constants';

let menu: HTMLElement | undefined;
let tabs: Element[] | undefined;
let hasTabs: boolean;
let width: number;
let height: number;
let animation: number;

export function init() {
  menu = document.querySelector('unico-menu') as HTMLElement;
  tabs = Array.from(document.querySelectorAll('menu-tab'));
  hasTabs = tabs && tabs.length > 0;

  setHeight();

  if (hasTabs) {
    animation = (tabs[0] as HTMLElement).offsetWidth;

    tabs.forEach((tab, i) => {
      setPosition(tab, i);
      setNavigation(tab);
    });
  }
}

function setHeight(i?: number) {
  const index = i || 0;
  height = 0;

  if (menu) {
    const content = Array.from(hasTabs ? tabs![index].children : menu.children);

    if (content) {
      content.forEach((c) => (height += (c as HTMLElement).offsetHeight));
      menu.style.setProperty('--height', `${height}px`);
    }
  }
}

function setWidth(i: number) {
  width = Number((tabs![i] as HTMLElement).getAttribute('width'));

  width
    ? menu!.style.setProperty('--width', `${width}px`)
    : menu!.style.setProperty('--width', '');
}

function setPosition(tab: Element, i: number) {
  tab.setAttribute('index', `${i}`);
  (tab as HTMLElement).style.left = `${animation * i}px`;
}

function setNavigation(tab: Element) {
  const nextButton = tab.querySelector('menu-next-button') as HTMLElement;
  const prevButton = tab.querySelector('menu-prev-button') as HTMLElement;

  nextButton
    && nextButton.addEventListener('click', ({ target }) => {
      nav(target!, 'next');
      toggleActive(nextButton);
    });

  prevButton
    && prevButton.addEventListener('click', ({ target }) => {
      nav(target!, 'prev');
      toggleActive(prevButton);
    });
}

function toggleActive(target: Element) {
  target.classList.add('active');
  setTimeout(() => {
    target.classList.remove('active');
  }, 500);
}

function nav(t: EventTarget, d: 'next' | 'prev') {
  const direction = d === 'next' ? '-' : '+';
  const index = Number(
    (t as HTMLElement).closest('menu-tab')!.getAttribute('index'),
  );
  const target = d === 'next' ? index + 1 : index - 1;

  if (hasTabs) {
    tabs!.forEach((t) => {
      const tab = t as HTMLElement;
      const prevLeft = tab.style.left;

      tab.style.left = `calc(${prevLeft} ${direction} ${animation}px)`;
    });

    setHeight(target);
    setWidth(target);

    menu!.style.transition = `width 0.5s ${EASE}, height 0.5s ${EASE}`;
    setTimeout(() => {
      menu!.style.transition = '';
    }, 500);
  }
}

export function resetMenu() {
  if (hasTabs) {
    setTimeout(() => {
      tabs!.forEach((tab, i) => {
        (tab as HTMLElement).style.left = `${animation * i}px`;
      });
      setHeight();
    }, 500);
  }
}

export function timer(
  close: React.Dispatch<React.SetStateAction<boolean>> | undefined,
) {
  if (close) {
    window.timerId = setTimeout(() => {
      close(false);
      resetMenu();
    }, 2000);
  }
}
