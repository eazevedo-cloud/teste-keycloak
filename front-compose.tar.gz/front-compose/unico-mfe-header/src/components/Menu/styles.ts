import styled from '@emotion/styled';

import {
  EASE, DESKTOP, HOVER, TABLET,
} from '@utils/styles/constants';
import { MenuProps } from './types';

export const Container = styled.div<MenuProps>`
  --width: ${(props) => (props.width ? `${props.width}px` : '220px')};
  --height: 0;

  background-color: #fff;
  width: var(--width);
  height: 0;
  overflow: hidden;
  border-radius: 5px;
  opacity: 0;
  transition: ${(props) => (props.fx === 'fade'
    ? 'opacity 0.5s, height 0s 0.5s'
    : props.fx === 'slide'
      ? 'opacity 0.3s, height 0.3s'
      : '')};
  -webkit-box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.6);
  -moz-box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.6);
  box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.6);
  position: absolute;
  top: 68px;
  right: 10px;
  z-index: 11;

  &.open {
    height: var(--height);
    opacity: 1;
    transition: ${(props) => (props.fx === 'fade'
    ? 'opacity 0.3s, height 0s'
    : props.fx === 'slide'
      ? `opacity 0.8s 0.2s, height 1s ${EASE}`
      : '')};
  }

  ul {
    padding: 8px;
    li {
      height: 48px;
    }
  }

  menu-tab {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    transition: left 0.5s ${EASE};
    display: block;
  }

  menu-next-button,
  menu-prev-button {
    padding-inline: 8px;
    display: block;

    &.active {
      pointer-events: none;
    }

    li {
      height: 48px;
      padding-inline: 10px;
      transition: background-color 0.2s;

      &:hover {
        background-color: ${HOVER};
      }

      > div:nth-child(3) {
        min-width: 24px;
      }
    }

    hr {
      margin-bottom: 0 !important;
    }
  }

  menu-prev-button {
    padding-top: 8px;
  }

  @media (${TABLET}) {
    display: ${(props) => (props.desktop ? 'none' : '')};
  }

  @media (${DESKTOP}) {
    display: ${(props) => (props.mobile ? 'none' : '')};
  }
`;
