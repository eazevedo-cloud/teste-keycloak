import { render, screen, fireEvent } from '@testing-library/react';
import { SessionContext, UserProvider } from 'contexts';
import { SessionContextType } from 'contexts/session/SessionContext';
import Menu from './Menu';
import { init, timer } from './actions';

jest.mock('./actions', () => ({
  init: jest.fn(),
  timer: jest.fn(),
}));

jest.mock('../MultiAccount', () => ({
  MultiAccountAllButton: jest.fn(() => <div>Mocked MultiAccountAllButton</div>),
  MultiAccountBackButton: jest.fn(() => <div>Mocked MultiAccountBackButton</div>),
  MultiAccountHeader: jest.fn(() => <div>Mocked MultiAccountHeader</div>),
}));

jest.spyOn(global, 'clearTimeout');

window.customElements = {
  define: jest.fn(),
  get: jest.fn(),
  upgrade: jest.fn(),
  whenDefined: jest.fn(() => Promise.resolve()),
} as any;

const renderComponent = (overrides?: Partial<SessionContextType>) => {
  const defaultAuthContext: SessionContextType = {
    tokenData: null,
    userInfo: {
      name: 'Jane Doe',
      document: '12345678901',
      accounts: [
        { name: 'Account 1', document: '12345678901' },
        { name: 'Account 2', document: '98765432100' },
        { name: 'Account 3', document: '11223344556' },
      ],
    },
    points: '',
    hasSessionExpired: false,
    isLoadingBalance: false,
    errorToFetchBalance: false,
    fetchBalance: jest.fn(),
    saveTokenData: jest.fn(),
    setUserInfo: jest.fn(),
    setPoints: jest.fn(),
    logout: jest.fn(),
  };

  return render(
    <UserProvider>
      <SessionContext.Provider value={{ ...defaultAuthContext, ...overrides }}>
        <Menu open close={jest.fn()} />
      </SessionContext.Provider>
    </UserProvider>,
  );
};

describe('menu Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should call init on mount', () => {
    renderComponent();
    expect(init).toHaveBeenCalled();
  });

  it('should render MultiAccountHeader when multiple accounts are present', () => {
    renderComponent();
    expect(screen.getByText('Mocked MultiAccountHeader')).toBeInTheDocument();
  });

  it('should render MultiAccountAllButton when more than two accounts are present', () => {
    renderComponent();
    expect(screen.getByText('Mocked MultiAccountAllButton')).toBeInTheDocument();
  });

  it('should render MultiAccountBackButton when more than two accounts are present and in the second tab', () => {
    renderComponent();
    expect(screen.getByText('Mocked MultiAccountBackButton')).toBeInTheDocument();
  });

  it('should call timer on mouse leave', () => {
    renderComponent();
    const menu = screen.getByRole('menu');
    fireEvent.mouseLeave(menu);
    expect(timer).toHaveBeenCalled();
  });

  it('should clear timer on mouse enter', () => {
    renderComponent();
    const menu = screen.getByRole('menu');
    fireEvent.mouseEnter(menu);
    expect(clearTimeout).toHaveBeenCalled();
  });

  it('should render MenuList with correct variant', () => {
    renderComponent();
    expect(screen.getByLabelText('opções do menu')).toBeInTheDocument();
  });
});
