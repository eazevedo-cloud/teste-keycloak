export type MenuProps = React.ComponentProps<"div"> & {
  open?: boolean;
  close?: React.Dispatch<React.SetStateAction<boolean>>;
  fx?: "fade" | "slide";
  desktop?: boolean;
  mobile?: boolean;
  width?: number;
};
