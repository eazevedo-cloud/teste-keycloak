import { useEffect } from 'react';

import { Divider } from '@unicred/uds-core';

import { useAuth } from 'contexts';
import { Container } from './styles';
import { MenuProps } from './types';
import { UnicoMenu } from './web.comp';
import { init, timer } from './actions';
import { MenuList, MultiAccount } from '..';
import {
  MultiAccountAllButton,
  MultiAccountBackButton,
  MultiAccountHeader,
} from '../MultiAccount';

customElements.define('unico-menu', UnicoMenu);

const Menu = ({ open, close, ...props }: MenuProps) => {
  const { userInfo } = useAuth();
  const { accounts } = (userInfo!);
  const quantity = accounts.length;

  useEffect(() => {
    init();
  }, []);

  return (
    <Container
      width={quantity > 1 ? 350 : 220}
      className={open ? 'open' : ''}
      role="menu"
      aria-label="menu do usuário"
      onMouseEnter={() => clearTimeout(window.timerId)}
      onMouseLeave={() => timer(close)}
      as="unico-menu"
      {...props}
    >
      {quantity && quantity > 1 ? (
        <>
          <menu-tab>
            <MultiAccountHeader />
            <MultiAccount show={2} />

            {quantity > 2 ? (
              <menu-next-button>
                <MultiAccountAllButton />
                <Divider />
              </menu-next-button>
            ) : (
              <Divider />
            )}

            <MenuList close={close} variant="user" />
          </menu-tab>

          {quantity > 2 && (
            <menu-tab>
              <menu-prev-button>
                <MultiAccountBackButton />
                <Divider />
              </menu-prev-button>

              <MultiAccount />
            </menu-tab>
          )}
        </>
      ) : (
        <MenuList close={close} variant="user" />
      )}
    </Container>
  );
};

export default Menu;
