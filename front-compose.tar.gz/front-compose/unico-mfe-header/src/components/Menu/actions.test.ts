import { init, resetMenu, timer } from './actions';

describe('menu Actions', () => {
  let menuMock;
  let tabsMock: NodeListOf<HTMLElement>;

  beforeEach(() => {
    document.body.innerHTML = `
      <div id="root">
        <unico-menu>
          <menu-tab></menu-tab>
          <menu-tab></menu-tab>
        </unico-menu>
      </div>`;

    menuMock = document.querySelector('unico-menu');
    tabsMock = document.querySelectorAll('menu-tab');
  });

  afterEach(() => {
    document.body.innerHTML = '';
  });

  it('should initialize menu and set tab positions', () => {
    init();

    tabsMock.forEach((tab, index) => {
      expect(tab).toHaveAttribute('index', String(index));
      expect(tab.style.left).toBeDefined();
    });
  });

  it('should reset menu positions after resetMenu is called', (done) => {
    resetMenu();

    setTimeout(() => {
      tabsMock.forEach((tab, index) => {
        expect(tab.style.left).toBeDefined();
      });
      done();
    }, 500);
  });

  it('should call timer and trigger resetMenu', (done) => {
    const mockClose = jest.fn();
    timer(mockClose);

    setTimeout(() => {
      expect(mockClose).toHaveBeenCalledWith(false);
      done();
    }, 2000);
  });
});
