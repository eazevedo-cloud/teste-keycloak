/* eslint-disable max-len */
import { render, screen, fireEvent } from '@testing-library/react';
import useTokenHandler from '@hooks/useTokenHandler';
import UserArea from './UserArea';
import { useAuth, useUserContext } from '../../contexts';
import { closeOtherDrawers } from '../Drawer/actions';
import { resetMenu } from '../Menu/actions';

jest.mock('../../contexts', () => ({
  useAuth: jest.fn(),
  useUserContext: jest.fn(),
}));

jest.mock('@hooks/useTokenHandler', () => jest.fn());

jest.mock('../Drawer/actions', () => ({
  closeOtherDrawers: jest.fn(),
  init: jest.fn(),
}));

jest.mock('../Menu/actions', () => ({
  resetMenu: jest.fn(),
  init: jest.fn(),
}));

describe('userArea', () => {
  const mockUseAuth = useAuth as jest.Mock;
  const mockUseUserContext = useUserContext as jest.Mock;
  const mockUseTokenHandler = useTokenHandler as jest.Mock;

  const renderComponent = ({ authStateOverrides = {}, isDesktop = true, isMobile = false } = {}) => {
    mockUseAuth.mockReturnValue({
      userInfo: {
        name: 'John Doe',
        document: '12345678901',
        accounts: [
          { name: 'Account 1', document: '12345678901' },
          { name: 'Account 2', document: '98765432100' },
        ],
      },
      points: '1000',
      errorToFetchBalance: false,
      isLoadingBalance: false,
      fetchBalance: jest.fn(),
      saveTokenData: jest.fn(),
      setUserInfo: jest.fn(),
      setPoints: jest.fn(),
      logout: jest.fn(),
      ...authStateOverrides,
    });

    mockUseUserContext.mockReturnValue({
      isDesktop,
      isMobile,
      isActive: jest.fn().mockReturnValue(true),

    });

    mockUseTokenHandler.mockReturnValue({
      isReadyToRender: true,
      firstName: 'John',
      setFirstName: jest.fn(),
    });

    return render(<UserArea />);
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render user points when userInfo is available', () => {
    renderComponent();

    expect(screen.getByText(/Saldo/i)).toBeInTheDocument();
    expect(screen.getByText(/1.000 pts/i)).toBeInTheDocument();
  });

  it('should render skeleton when isLoadingBalance is true', () => {
    renderComponent({ authStateOverrides: { isLoadingBalance: true } });
    expect(screen.getByTestId('uds-skeleton-component')).toBeInTheDocument();
  });

  it('should render button to load balance when errorToFetchBalance is true', () => {
    renderComponent({ authStateOverrides: { errorToFetchBalance: true } });
    expect(screen.getByRole('button', { name: /carregar saldo/i })).toBeInTheDocument();
  });

  it('should call fetchBalance when load balance button is clicked', () => {
    const fetchBalanceMock = jest.fn();
    renderComponent({ authStateOverrides: { errorToFetchBalance: true, fetchBalance: fetchBalanceMock } });
    fireEvent.click(screen.getByRole('button', { name: /carregar saldo/i }));
    expect(fetchBalanceMock).toHaveBeenCalledWith('12345678901');
  });

  it('should open drawer when user icon is clicked on mobile', () => {
    renderComponent({ isDesktop: false, isMobile: true });
    fireEvent.click(screen.getByRole('button', { name: /minha conta/i }));
    expect(closeOtherDrawers).toHaveBeenCalled();
  });

  it('should open menu when user button is clicked on desktop', () => {
    renderComponent();
    const userMenuButton = screen.getByRole('button', { name: /menu do usuário/i });
    fireEvent.click(userMenuButton);
    expect(userMenuButton).toHaveClass('open');
    fireEvent.click(userMenuButton);
    expect(resetMenu).toHaveBeenCalled();
  });

  it('should render login button when userInfo is not available', () => {
    renderComponent({ authStateOverrides: { userInfo: null } });
    expect(screen.getByRole('button', { name: /acessar conta/i })).toBeInTheDocument();
  });

  it('should render skeleton while not ready to render', () => {
    mockUseTokenHandler.mockReturnValueOnce({
      ...mockUseTokenHandler(),
      isReadyToRender: false,
    });

    render(<UserArea />);

    expect(screen.getByTestId('uds-skeleton-component')).toBeInTheDocument();
  });
});
