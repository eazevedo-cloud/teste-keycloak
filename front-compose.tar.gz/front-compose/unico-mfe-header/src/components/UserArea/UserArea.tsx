import { useEffect, useState } from 'react';

import {
  Button, Skeleton, Typography, IconButton,
} from '@unicred/uds-core';
import { UdsChevronDown, UdsUpdate, UdsUserFilled } from '@unicred/uds-icons';

import useTokenHandler from '@hooks/useTokenHandler';
import { formatNumber } from '@utils/data/formatNumber';
import { Container } from './styles';
import { UnicoUserArea } from './web.comp';
// eslint-disable-next-line import/no-cycle
import { AccountLabel, Drawer, Menu } from '..';
import { useAuth, useUserContext } from '../../contexts';
import { resetMenu } from '../Menu/actions';
import { closeOtherDrawers } from '../Drawer/actions';

customElements.define('unico-user-area', UnicoUserArea);

const UserArea = () => {
  const {
    userInfo,
    points,
    errorToFetchBalance,
    isLoadingBalance,
    fetchBalance,
  } = useAuth();

  const { isDesktop, isMobile } = useUserContext();
  const { isReadyToRender, firstName, setFirstName } = useTokenHandler();

  const [menuOpen, setMenuOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const urlLogin = process.env.NODE_ENV === 'production'
    ? process.env.URL_LOGIN
    : process.env.URL_LOGIN_LOCAL;

  useEffect(() => {
    if (userInfo) setFirstName(userInfo!.name.split(' ')[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userInfo]);

  return (
    <Container as="unico-user-area" aria-label="area do usuário">
      {isReadyToRender ? (
        userInfo ? (
          <>
            {isLoadingBalance ? (
              <Skeleton width={160} />
            ) : (
              <user-points aria-label="pontos do usuário">
                {errorToFetchBalance ? (
                  <Button
                    id="user-load-balance-button"
                    title="Carregar saldo"
                    aria-label="carregar saldo"
                    variant="text"
                    endIcon={<UdsUpdate color="action" />}
                    onClick={() => fetchBalance(userInfo.document)}
                  >
                    <Typography variant="subtitle2" color="text.primary">
                      Carregar saldo
                    </Typography>
                  </Button>
                ) : (
                  <>
                    <Typography
                      variant="caption"
                      role="heading"
                      aria-label="saldo"
                    >
                      Saldo
                    </Typography>
                    <Typography variant="n6" aria-label="pontos">
                      {formatNumber(points)}
                      {' '}
                      pts
                    </Typography>
                  </>
                )}
              </user-points>
            )}

            <user-nav role="navigation" aria-label="navegação do usuário">
              {isMobile ? (
                <IconButton
                  id="user-menu-icon-button"
                  aria-label="minha conta"
                  aria-controls="unico-drawer"
                  aria-expanded={drawerOpen ? 'true' : 'false'}
                  onClick={() => {
                    closeOtherDrawers();
                    setDrawerOpen(true);
                  }}
                >
                  <UdsUserFilled />
                </IconButton>
              ) : (
                <Button
                  id="user-menu-button"
                  aria-label="menu do usuário"
                  aria-controls={isDesktop ? 'unico-menu' : 'unico-drawer'}
                  aria-haspopup={isDesktop ? 'true' : 'false'}
                  aria-expanded={menuOpen || drawerOpen ? 'true' : 'false'}
                  variant="text"
                  title="Menu do usuário"
                  onClick={() => {
                    if (isDesktop) {
                      setMenuOpen(!menuOpen);
                      clearTimeout(window.timerId);
                      // eslint-disable-next-line @typescript-eslint/no-unused-expressions
                      menuOpen && resetMenu();
                    } else {
                      closeOtherDrawers();
                      setDrawerOpen(true);
                    }
                  }}
                  endIcon={<UdsChevronDown />}
                  className={menuOpen ? 'open' : ''}
                >
                  <AccountLabel
                    prefix="Olá,"
                    name={firstName}
                    document={userInfo.document}
                  />
                </Button>
              )}

              {isDesktop && (
                <Menu
                  open={menuOpen}
                  close={() => setMenuOpen(false)}
                  fx="fade"
                  desktop
                />
              )}
            </user-nav>
          </>
        ) : (
          <Button
            id="user-account-button"
            title="Acessar conta"
            href={urlLogin}
            variant="contained"
          >
            Acessar
            {' '}
            <span>conta</span>
          </Button>
        )
      ) : (
        <Skeleton width={320} sx={{ marginRight: 3 }} />
      )}

      {!isDesktop && (
        <Drawer
          variant="user"
          open={drawerOpen}
          close={() => setDrawerOpen(false)}
          mobile
        />
      )}
    </Container>
  );
};

export default UserArea;
