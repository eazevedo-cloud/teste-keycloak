import styled from '@emotion/styled';
import { MOBILE, TEXT_PRIMARY } from '@utils/styles/constants';

export const Container = styled.div`
  height: 100%;
  margin-left: auto;
  display: flex;

  user-points {
    color: ${TEXT_PRIMARY};
    display: flex;
    flex-direction: column;
    justify-content: center;

    p {
      margin-right: 16px;
      padding-bottom: 4px;
      line-height: 18px;
    }

    #user-load-balance-button {
      height: 100%;
      padding: 0 20px 2px 20px;
      border-radius: 0;
      text-transform: none;
      color: ${TEXT_PRIMARY};
    }
  }

  user-nav {
    display: block;
    position: relative;

    #user-menu-button {
      height: 100%;
      padding-inline: 24px;
      border-radius: 0;
      text-transform: none;
      color: ${TEXT_PRIMARY};

      &.open {
        background-color: #094d380a;
      }

      // Account label
      > div {
        padding: 9px 15px 0 0;
        account-name {
          margin-bottom: 1px;
        }
      }

      // Button icon
      > span {
        margin-left: 0;
      }

      @media (${MOBILE}) {
        display: none;
      }
    }

    #user-menu-icon-button {
      margin-top: 13px;
      display: none;

      @media (${MOBILE}) {
        display: inline-flex;
      }
    }
  }

  #user-account-button {
    height: 44px;
    margin: 12px 24px 0 0;

    span {
      margin-left: 5px;
    }

    @media (${MOBILE}) {
      margin-right: 0;
      span {
        display: none;
      }
    }
  }
`;
