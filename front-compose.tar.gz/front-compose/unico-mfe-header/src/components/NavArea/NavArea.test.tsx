import { render, screen, fireEvent } from '@testing-library/react';
import { UserProvider } from 'contexts';
import NavArea from './NavArea';

jest.mock('../Drawer/actions', () => ({
  closeOtherDrawers: jest.fn(),
}));
jest.mock('../Logo/Logo.tsx', () => () => <div data-testid="logo">Logo</div>);
jest.mock('../Navigation/Navigation.tsx', () => () => <nav data-testid="navigation">Navigation</nav>);
jest.mock('../Drawer/Drawer.tsx', () => (props: any) => (
  <div data-testid="drawer" {...props}>Drawer</div>
));

const renderComponent = (overrides?: Partial<{ isDesktop: boolean }>) => render(
  <UserProvider>
    <NavArea />
  </UserProvider>,
);

describe('navArea', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render the Logo component', () => {
    renderComponent();
    expect(screen.getByTestId('logo')).toBeInTheDocument();
  });

  it('should render Navigation component when on desktop', () => {
    renderComponent({ isDesktop: true });
    expect(screen.getByLabelText('area de navegação')).toBeInTheDocument();
  });

  it('should render IconButton and Drawer when not on desktop', () => {
    renderComponent({ isDesktop: false });
    expect(screen.getByLabelText('menu de opções')).toBeInTheDocument();
    expect(screen.getByTestId('drawer')).toBeInTheDocument();
  });

  it('should open the drawer when IconButton is clicked', () => {
    renderComponent({ isDesktop: false });

    const menuButton = screen.getByLabelText('menu de opções');
    fireEvent.click(menuButton);

    expect(screen.getByTestId('drawer')).toBeVisible();
  });
});
