import styled from '@emotion/styled';
import { TABLET } from '@utils/styles/constants';

export const Container = styled.div`
  height: 100%;
  display: flex;
  align-items: center;

  #user-nav-icon-button {
    margin: 0 16px 1px 0;
    display: none;

    @media (${TABLET}) {
      display: inline-flex;
    }
  }

  unico-logo {
    margin-bottom: 4px;
  }

  #main-nav {
    @media (${TABLET}) {
      display: none;
    }
  }
`;
