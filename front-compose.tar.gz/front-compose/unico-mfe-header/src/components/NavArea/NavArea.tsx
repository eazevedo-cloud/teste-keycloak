import { useState } from 'react';

import { IconButton } from '@unicred/uds-core';
import { UdsMenu } from '@unicred/uds-icons';

import { useUserContext } from 'contexts';
import { UnicoNavArea } from './web.comp';
import { Container } from './styles';
import { Drawer, Logo, Navigation } from '..';
import { closeOtherDrawers } from '../Drawer/actions';

customElements.define('unico-nav-area', UnicoNavArea);

const NavArea = () => {
  const { isDesktop } = useUserContext();
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <Container as="unico-nav-area" aria-label="area de navegação">
      {!isDesktop && (
        <IconButton
          id="user-nav-icon-button"
          title="Menu de opções"
          aria-label="menu de opções"
          aria-controls="unico-drawer"
          aria-expanded={drawerOpen ? 'true' : 'false'}
          onClick={() => {
            closeOtherDrawers();
            setDrawerOpen(true);
          }}
        >
          <UdsMenu />
        </IconButton>
      )}

      <Logo href="/" />

      {isDesktop ? (
        <Navigation />
      ) : (
        <Drawer
          variant="navigation"
          open={drawerOpen}
          close={() => setDrawerOpen(false)}
          mobile
          left
        />
      )}
    </Container>
  );
};

export default NavArea;
