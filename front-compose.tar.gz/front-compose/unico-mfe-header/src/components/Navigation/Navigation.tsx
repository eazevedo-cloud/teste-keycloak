import { MENU_LINKS_MAP } from '@utils/data/menuLinks';
import { useUserContext } from 'contexts';
import { NavLink } from '..';
import { Nav, List, Item } from './styles';

const Navigation = () => {
  const { isActive } = useUserContext();

  return (
    <Nav id="main-nav" aria-label="navegação principal">
      <List>
        <Item className={isActive('Shopping') ? 'active' : ''}>
          <NavLink
            text="Shopping"
            title="Shopping"
            href={MENU_LINKS_MAP?.SHOPPING}
            width="84px"
            active={isActive('Shopping')}
          />
        </Item>
        <Item className={isActive('Produtos Unicred') ? 'active' : ''}>
          <NavLink
            text="Produtos Unicred"
            title="Produtos Unicred"
            href={MENU_LINKS_MAP?.PRODUTOS_UNICRED}
            width="157px"
            active={isActive('Produtos Unicred')}
          />
        </Item>
        <Item className={isActive('Transferir pontos') ? 'active' : ''}>
          <NavLink
            text="Transferir pontos"
            title="Transferir pontos"
            href={MENU_LINKS_MAP?.TRANSFERIR_PONTOS}
            width="157px"
            active={isActive('Transferir pontos')}
          />
        </Item>
      </List>
    </Nav>
  );
};

export default Navigation;
