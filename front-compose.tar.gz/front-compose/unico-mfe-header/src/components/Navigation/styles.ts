import styled from '@emotion/styled';
import { EASE, TEXT_SECONDARY } from '@utils/styles/constants';

export const Nav = styled.nav`
  height: 100%;
  margin-left: 40px;
  padding-bottom: 3px;

  &.scrolling {
    li:not(.active) {
      margin-right: 0;
      padding: 0;
      transition:
        margin 0.3s ${EASE} 0.3s,
        padding 0.3s ${EASE} 0.3s;

      a {
        width: 0;
        opacity: 0;
        transition:
          width 0.3s ${EASE} 0.3s,
          opacity 0.3s;
      }
    }
  }
`;

export const List = styled.ul`
  height: 100%;
  display: flex;
`;

export const Item = styled.li`
  height: 100%;
  margin-right: 8px;
  padding: 11px 8px;
  overflow: hidden;
  transition:
    margin 0.3s ${EASE},
    padding 0.3s ${EASE};
  display: flex;
  align-items: center;

  &:last-child {
    margin-right: 0;
  }

  &.active {
    a {
      pointer-events: none;
    }
  }

  a {
    font-size: 18px;
    line-height: 32px;
    font-weight: 600;
    color: ${TEXT_SECONDARY};
    opacity: 1;
    transition:
      width 0.3s ${EASE} 0s,
      opacity 0.3s 0.3s;
    display: block;

    &:hover {
      color: ${TEXT_SECONDARY} !important;
    }
  }
`;
