import { render, screen } from '@testing-library/react';
import { UserContext } from 'contexts';
import Navigation from './Navigation';

jest.mock('..', () => ({
  NavLink: jest.fn(({ text }) => <div>{text}</div>),
}));

describe('navigation Component', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  const isActive = jest.fn();

  const renderComponent = () => {
    const providerDefaultValue = {
      isDesktop: true,
      isTablet: false,
      isMobile: false,
      isOnline: false,
      isActive,
    };

    return render(
      <UserContext.Provider value={providerDefaultValue}>
        <Navigation />
      </UserContext.Provider>,
    );
  };

  it('should render the navigation container with the correct aria-label', () => {
    renderComponent();
    expect(screen.getByLabelText('navegação principal')).toBeInTheDocument();
  });

  it('should render the Shopping NavLink', () => {
    renderComponent();
    expect(screen.getByText('Shopping')).toBeInTheDocument();
  });

  it('should render the Produtos Unicred NavLink', () => {
    renderComponent();
    expect(screen.getByText('Produtos Unicred')).toBeInTheDocument();
  });

  it('should render the Transferir pontos NavLink', () => {
    renderComponent();
    expect(screen.getByText('Transferir pontos')).toBeInTheDocument();
  });
});
