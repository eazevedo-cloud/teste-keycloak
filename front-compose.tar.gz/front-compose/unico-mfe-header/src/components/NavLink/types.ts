export type NavLinkProps = {
  text: string;
  title?: string;
  width?: string;
  href: string;
  active?: boolean;
};
