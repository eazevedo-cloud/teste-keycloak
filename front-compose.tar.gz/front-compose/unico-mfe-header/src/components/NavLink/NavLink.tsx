import { Link } from '@unicred/uds-core';

import { goPointsEvent } from '@utils/events';
import { useAuth } from '../../contexts';
import { NavLinkProps } from './types';

const NavLink = ({
  text, title, width, href, active,
}: NavLinkProps) => {
  const { userInfo } = useAuth();

  return (
    // eslint-disable-next-line jsx-a11y/anchor-is-valid
    <Link
      underline="hover"
      title={title}
      width={width}
      sx={{
        color: (theme: any) => (active ? `${theme.palette.primary.main} !important` : ''),
      }}
      onClick={({ target }) => goPointsEvent(
        'unicoURLValid',
        (target as HTMLElement).innerHTML,
        href,
        userInfo,
      )}
    >
      {text}
    </Link>
  );
};

export default NavLink;
