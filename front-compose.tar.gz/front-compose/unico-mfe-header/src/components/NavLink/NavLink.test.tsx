import { render, screen, fireEvent } from '@testing-library/react';
import { goPointsEvent } from '@utils/events';
import NavLink from './NavLink';
import { useAuth } from '../../contexts';
import { MENU_LINKS_MAP } from '@utils/data/menuLinks';

jest.mock('../../contexts', () => ({
  useAuth: jest.fn(() => ({
    userInfo: { name: 'Test User', document: '12345678901' },
  })),
}));

jest.mock('@utils/events', () => ({
  goPointsEvent: jest.fn(),
}));

describe('NavLink Component', () => {
  const defaultProps = {
    text: 'Shopping',
    title: 'Shopping Title',
    width: '100px',
    href: MENU_LINKS_MAP?.SHOPPING,
    active: false,
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render NavLink correctly', () => {
    const { container } = render(<NavLink {...defaultProps} />);

    expect(container).toMatchSnapshot();
  });

  it('should render the link with the correct text and title', () => {
    render(<NavLink {...defaultProps} />);
    const linkElement = screen.getByText('Shopping');
    expect(linkElement).toBeInTheDocument();
    expect(linkElement).toHaveAttribute('title', 'Shopping Title');
  });

  it('should call goPointsEvent on click with correct parameters', () => {
    render(<NavLink {...defaultProps} />);
    const linkElement = screen.getByText('Shopping');
    fireEvent.click(linkElement);

    expect(goPointsEvent).toHaveBeenCalledWith(
      'unicoURLValid',
      'Shopping',
      MENU_LINKS_MAP?.SHOPPING,
      { name: 'Test User', document: '12345678901' },
    );
  });
});
