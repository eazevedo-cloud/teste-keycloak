import styled from '@emotion/styled';
import { MOBILE, TABLET } from '@utils/styles/constants';

export const Container = styled.header`
  background-color: #fff;
  width: 100%;
  height: 68px;
  padding-left: 24px;
  border-bottom: 1px solid #eee;
  display: flex;
  position: fixed;
  top: 0;
  z-index: 1000;

  @media (${TABLET}) {
    padding-left: 15px;
  }

  @media (${MOBILE}) {
    padding-right: 15px;
  }
`;
