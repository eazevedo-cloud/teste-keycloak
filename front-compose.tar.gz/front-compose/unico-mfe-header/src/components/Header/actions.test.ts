/**
 * @jest-environment jsdom
 */

import { handleScroll } from './actions';

let scrollEventCallback: (evt: Event) => void = () => { };
let prevScrollPosition = 0;

beforeAll(() => {
  jest.spyOn(window, 'addEventListener').mockImplementation((event, callback) => {
    if (event === 'scroll') {
      scrollEventCallback = callback as (evt: Event) => void;
    }
  });

  jest.spyOn(window, 'removeEventListener').mockImplementation((event, callback) => {
    if (event === 'scroll' && scrollEventCallback === callback) {
      scrollEventCallback = () => { };
    }
  });
});

describe('handleScroll', () => {
  let navElement: HTMLElement;

  beforeEach(() => {
    document.body.innerHTML = '<div id="main-nav"></div>';
    navElement = document.getElementById('main-nav') as HTMLElement;
    prevScrollPosition = 0;
  });

  afterEach(() => {
    jest.clearAllMocks();
    document.body.innerHTML = '';
  });

  it('should add "scrolling" class when scrolling down', () => {
    Object.defineProperty(window, 'scrollY', { value: 100, writable: true });
    handleScroll();
    scrollEventCallback(new Event('scroll'));
    expect(navElement.classList.contains('scrolling')).toBe(true);
  });

  it('should remove "scrolling" class when scrolling up', () => {
    Object.defineProperty(window, 'scrollY', { value: 101, writable: true });
    handleScroll();
    scrollEventCallback(new Event('scroll'));
    expect(navElement.classList.contains('scrolling')).toBe(true);

    prevScrollPosition = 101;
    handleScroll();
    Object.defineProperty(window, 'scrollY', { value: 50, writable: true });
    scrollEventCallback(new Event('scroll'));
    expect(navElement.classList.contains('scrolling')).toBe(false);
  });
});
