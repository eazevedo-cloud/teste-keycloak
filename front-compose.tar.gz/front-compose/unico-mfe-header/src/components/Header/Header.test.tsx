import { render, screen } from '@testing-library/react';
import { useAuth } from 'contexts';
import Header from './Header';
import { Alert } from '@unicred/uds-core';
import { NavArea, UserArea } from '..';

jest.mock('contexts', () => ({
  useAuth: jest.fn(),
}));

jest.mock('@unicred/uds-core', () => ({
  Alert: jest.fn(({ children }) => <div>{children}</div>),
}));

jest.mock('..', () => ({
  NavArea: jest.fn(() => <div>Mocked NavArea</div>),
  UserArea: jest.fn(() => <div>Mocked UserArea</div>),
}));

jest.mock('./actions', () => ({
  handleScroll: jest.fn(),
}));

describe('Header', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render NavArea and UserArea components', () => {
    (useAuth as jest.Mock).mockReturnValue({ hasSessionExpired: false });
    render(<Header />);
    expect(screen.getByText('Mocked NavArea')).toBeInTheDocument();
    expect(screen.getByText('Mocked UserArea')).toBeInTheDocument();
  });

  it('should render alert when session has expired', () => {
    (useAuth as jest.Mock).mockReturnValue({ hasSessionExpired: true });
    render(<Header />);
    expect(screen.getByText('Sua sessão expirou. Por favor, acesse sua conta novamente.')).toBeInTheDocument();
  });

  it('should not render alert when session has not expired', () => {
    (useAuth as jest.Mock).mockReturnValue({ hasSessionExpired: false });
    render(<Header />);
    expect(screen.queryByText('Sua sessão expirou. Por favor, acesse sua conta novamente.')).not.toBeInTheDocument();
  });
});
