import { useEffect } from 'react';

import { useAuth } from 'contexts';
import { Alert } from '@unicred/uds-core';
import { Container } from './styles';
import { handleScroll } from './actions';
import { NavArea, UserArea } from '..';

const Header = () => {
  const { hasSessionExpired } = useAuth();

  useEffect(() => {
    const scrollFX = () => window.addEventListener('scroll', handleScroll);
    scrollFX();

    return window.removeEventListener('scroll', scrollFX);
  }, []);

  return (
    <Container aria-label="cabeçalho canal único">
      <NavArea />
      <UserArea />

      {hasSessionExpired && (
        <Alert
          severity="error"
          sx={{
            position: 'fixed',
            width: '280px',
            height: '70px',
            inset: 0,
            margin: 'auto auto 15px',
            boxShadow: '0 0 5px 5px #00000020',
            display: 'flex',
            alignItems: 'center',
            zIndex: 99,
          }}
        >
          Sua sessão expirou. Por favor, acesse sua conta novamente.
        </Alert>
      )}
    </Container>
  );
};

export default Header;
