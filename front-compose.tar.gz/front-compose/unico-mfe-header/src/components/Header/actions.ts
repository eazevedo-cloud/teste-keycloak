let prevScrollPosition: number = 0;

function isScrollingDown() {
  let scrollPosition = window.scrollY;
  let isGoingDown = false;

  if (scrollPosition > prevScrollPosition) isGoingDown = true;
  prevScrollPosition = scrollPosition;

  return isGoingDown;
}

export function handleScroll() {
  const nav = document.getElementById("main-nav");

  if (nav) {
    isScrollingDown()
      ? nav.classList.add("scrolling")
      : nav.classList.remove("scrolling");
  }
}
