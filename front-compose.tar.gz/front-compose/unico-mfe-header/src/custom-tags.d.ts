export as namespace JSX;

export interface IntrinsicElements {
  "unico-drawer": HTMLElement;
  "unico-logo": HTMLElement;
  "unico-menu": HTMLElement;
  "unico-nav-area": HTMLElement;
  "unico-user-area": HTMLElement;

  "account-avatar": any;
  "account-document": any;
  "account-info": any;
  "account-name": any;
  "drawer-tab": any;
  "drawer-next-button": any;
  "drawer-prev-button": any;
  "drawer-wrapper": any;
  "menu-tab": any;
  "menu-next-button": any;
  "menu-prev-button": any;
  "user-nav": any;
  "user-points": any;
}
