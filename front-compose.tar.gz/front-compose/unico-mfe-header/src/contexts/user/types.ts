export type UserContextProps = {
  isDesktop: boolean;
  isTablet: boolean;
  isMobile: boolean;
  isOnline: boolean;
  isActive: (link: string) => boolean;
};
