import {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useState,
} from 'react';

import { useDevice, useOnline } from '@hooks/index';
import { UserContextProps } from './types';

export const UserContext = createContext<UserContextProps | undefined>(undefined);

export const useUserContext = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUserContext must be used within an UserProvider');
  }
  return context;
};

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const navigation = ['Shopping', 'Produtos Unicred', 'Transferir pontos'];
  const [activeLink, setActiveLink] = useState('');
  const isActive = (link: string) => link === activeLink;

  const isDesktop = useDevice('desktop');
  const isTablet = useDevice('tablet');
  const isMobile = useDevice('mobile');

  const isOnline = useOnline();

  useEffect(() => {
    const active = sessionStorage.getItem('active');

    active ? setActiveLink(active) : setActiveLink('Shopping');

    window.addEventListener('unicoURLValid', (event: Event) => {
      const path = (event as CustomEvent).detail.message;

      navigation.forEach((link) => {
        if (link === path) {
          setActiveLink(path);
          sessionStorage.setItem('active', path);
        }
      });
    });
  }, []);

  return (
    <UserContext.Provider
      value={{
        isDesktop,
        isTablet,
        isMobile,
        isOnline,
        isActive,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};
