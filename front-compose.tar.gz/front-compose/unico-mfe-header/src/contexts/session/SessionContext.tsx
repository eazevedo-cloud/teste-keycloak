import {
  createContext,
  useContext,
  useState,
  ReactNode,
  useEffect,
} from 'react';

import { goPointsEvent } from '@utils/events';
import { SessionTokenData } from '@interfaces/accessToken';
import { UserInfo } from '@interfaces/user';
import { authEventEmitter } from '@services/authEventEmitter';
import { getUserBalance } from '@services/user';
import { GetBalanceResponse } from '@services/types';
import { logoutUser } from '../../services/session';

export interface SessionContextType {
  tokenData: SessionTokenData | null;
  userInfo: UserInfo | null;
  points: string;
  hasSessionExpired: boolean;
  isLoadingBalance: boolean;
  errorToFetchBalance: boolean;
  fetchBalance: (document: string) => void;
  saveTokenData: (sessionToken: SessionTokenData, condition?: string) => void;
  setUserInfo: (userInfo: UserInfo | null) => void;
  setPoints: (points: string) => void;
  logout: () => void;
}

export const SessionContext = createContext<SessionContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(SessionContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [points, setPoints] = useState('');
  const [tokenData, setTokenData] = useState<SessionTokenData | null>(null);
  const [hasSessionExpired, setHasSessionExpired] = useState(false);
  const [isLoadingBalance, setIsLoadingBalance] = useState(false);
  const [errorToFetchBalance, setErrorToFetchBalance] = useState(false);

  const saveTokenData = (
    sessionToken: SessionTokenData,
    condition?: string,
  ) => {
    if (condition && condition === 'tokenAlreadyStored') {
      setTokenData(sessionToken);
    } else {
      const currentTime = new Date().getTime();
      const tokenExpirationTime = currentTime + sessionToken.expiresIn * 1000;
      const refreshExpirationTime = currentTime + sessionToken.refreshExpiresIn * 1000;

      const formattedData: SessionTokenData = {
        token: sessionToken.token,
        refreshToken: sessionToken.refreshToken,
        expiresIn: tokenExpirationTime,
        refreshExpiresIn: refreshExpirationTime,
      };

      setTokenData(formattedData);
      localStorage.setItem('tokenData', JSON.stringify(formattedData));
    }
  };

  async function fetchBalance(document: string) {
    setErrorToFetchBalance(false);

    setIsLoadingBalance(true);
    try {
      const { available }: GetBalanceResponse = await getUserBalance(document);

      setPoints(String(available));
    } catch (err) {
      setErrorToFetchBalance(true);
    } finally {
      setIsLoadingBalance(false);
    }
  }

  const logout = async () => {
    logoutUser();
    goPointsEvent('unicoLogoutAccount', 'Logout Account', '', userInfo);
    setUserInfo(null);
    setTokenData(null);
    localStorage.clear();
  };

  useEffect(() => {
    authEventEmitter.on('tokenUpdated', (newToken: SessionTokenData) => {
      goPointsEvent(
        'unicoSessionValid',
        'Sessão válida.',
        '',
        userInfo,
        newToken.token,
      );

      saveTokenData(newToken);
    });
    authEventEmitter.on('sessionExpired', () => {
      goPointsEvent(
        'unicoSessionInvalid',
        'Sessão expirada ou inválida.',
        '',
        userInfo,
      );

      setHasSessionExpired(true);
      setTimeout(() => {
        setHasSessionExpired(false);
      }, 5000);
      logout();
    });

    return () => {
      authEventEmitter.removeAllListeners();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <SessionContext.Provider
      // eslint-disable-next-line react/jsx-no-constructed-context-values
      value={{
        tokenData,
        userInfo,
        points,
        hasSessionExpired,
        isLoadingBalance,
        errorToFetchBalance,
        fetchBalance,
        saveTokenData,
        setUserInfo,
        setPoints,
        logout,
      }}
    >
      {children}
    </SessionContext.Provider>
  );
};
