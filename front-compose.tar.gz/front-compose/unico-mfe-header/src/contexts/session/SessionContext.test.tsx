import { act, render, waitFor } from '@testing-library/react';
import { goPointsEvent } from '@utils/events';
import { getUserBalance } from '@services/user';
import { logoutUser } from '@services/session';
import { AuthProvider, useAuth, SessionContextType } from './SessionContext';

jest.mock('@utils/events');
jest.mock('@services/authEventEmitter');
jest.mock('@services/user');
jest.mock('@services/session');

const TestComponent = ({ callback }: { callback: (context: SessionContextType) => void }) => {
  const context = useAuth();
  callback(context);
  return null;
};

describe('authProvider', () => {
  const renderWithAuthProvider = (callback: (context: SessionContextType) => void) => render(
    <AuthProvider>
      <TestComponent callback={callback} />
    </AuthProvider>,
  );

  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
    jest.spyOn(localStorage, 'setItem');
    jest.spyOn(localStorage, 'clear');
  });

  it('should provide default values', () => {
    renderWithAuthProvider((context) => {
      expect(context.tokenData).toBeNull();
      expect(context.userInfo).toBeNull();
      expect(context.points).toBe('');
      expect(context.hasSessionExpired).toBe(false);
      expect(context.isLoadingBalance).toBe(false);
      expect(context.errorToFetchBalance).toBe(false);
    });
  });

  it('should save token data and update context', () => {
    const tokenData = {
      token: 'mockToken',
      refreshToken: 'mockRefreshToken',
      expiresIn: 3600,
      refreshExpiresIn: 7200,
    };

    renderWithAuthProvider(async (context) => {
      act(() => {
        context.saveTokenData(tokenData);
      });

      await waitFor(() => {
        expect(context.tokenData).toEqual(expect.objectContaining(tokenData));
        expect(localStorage.setItem).toHaveBeenCalledWith('tokenData', JSON.stringify(expect.objectContaining(tokenData)));
      });
    });
  });

  it('should set userInfo when setUserInfo is called', () => {
    const userInfo = {
      name: 'John Doe',
      document: '12345678901',
      accounts: [],
    };

    renderWithAuthProvider(async (context) => {
      await act(async () => {
        context.setUserInfo(userInfo);
      });

      await waitFor(() => {
        expect(context.userInfo).toEqual(userInfo);
      });
    });
  });

  it('should handle logout correctly', () => {
    renderWithAuthProvider((context) => {
      act(() => {
        context.logout();
      });
      expect(logoutUser).toHaveBeenCalled();
      expect(goPointsEvent).toHaveBeenCalledWith('unicoLogoutAccount', 'Logout Account', '', null);
      expect(context.userInfo).toBeNull();
      expect(context.tokenData).toBeNull();
    });
  });

  it('should fetch balance and update points', async () => {
    const mockGetUserBalance = getUserBalance as jest.Mock;
    mockGetUserBalance.mockResolvedValue({ available: 1000 });

    renderWithAuthProvider(async (context) => {
      await act(async () => {
        context.fetchBalance('12345678901');
      });

      await waitFor(() => {
        expect(context.points).toBe('1000');
        expect(context.isLoadingBalance).toBe(false);
        expect(context.errorToFetchBalance).toBe(false);
      });
    });
  });
});
