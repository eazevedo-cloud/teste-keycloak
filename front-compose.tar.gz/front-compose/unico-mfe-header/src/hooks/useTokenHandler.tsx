import { useEffect, useState } from 'react';
import { jwtDecode } from 'jwt-decode';
import { goPointsEvent } from '@utils/events';
import { useAuth } from 'contexts';
import { AccessToken, SessionTokenData } from '@interfaces/accessToken';
import { UserInfo } from '@interfaces/user';
import { validateCPF } from '@utils/form';

const useTokenHandler = () => {
  const {
    userInfo, setUserInfo, fetchBalance, saveTokenData,
  } = useAuth();

  const [isReadyToRender, setIsReadyToRender] = useState(false);
  const [firstName, setFirstName] = useState('');

  function decodeAndSaveUserInfo(token: string, document?: string) {
    const decodedToken: AccessToken = jwtDecode(token);

    const selectedAccount = decodedToken.accounts.find((account) => account.document === document)
      || decodedToken.accounts.find((account) => validateCPF(account.document))
      || decodedToken.accounts[0];

    const decodedUser: UserInfo = {
      name: selectedAccount.name,
      document: selectedAccount.document,
      accounts: decodedToken.accounts,
    };

    setUserInfo(decodedUser);
    setFirstName(decodedUser.name.split(' ')[0]);

    return decodedUser;
  }

  function fetchSessionInfo(sessionToken: SessionTokenData | null) {
    if (userInfo) return;
    if (sessionToken && sessionToken.token) {
      const user = decodeAndSaveUserInfo(
        sessionToken.token,
        sessionToken?.document,
      );
      goPointsEvent('unicoSessionValid', 'Sessão válida', '', user);
      fetchBalance(user.document);
    } else {
      setUserInfo(null);
      goPointsEvent(
        'unicoSessionInvalid',
        'Sessão expirada ou inválida',
        '',
        null,
      );
    }
    setIsReadyToRender(true);
  }

  function extractTokenFromURL(hash: string) {
    const params = new URLSearchParams(hash.slice(1));

    const token = params.get('token') as string;
    const refreshToken = params.get('refreshToken') as string;
    const expiresIn = params.get('expiresIn') as string;
    const refreshExpiresIn = params.get('refreshExpiresIn') as string;
    const document = params.get('document') as string;

    const urlParams = {
      token,
      refreshToken,
      expiresIn: Number(expiresIn),
      refreshExpiresIn: Number(refreshExpiresIn),
      document,
    };

    saveTokenData(urlParams);
    fetchSessionInfo(urlParams);
    window.history.replaceState(null, '', window.location.pathname);
  }

  function verifyIfHasActiveSession() {
    const storedToken = localStorage.getItem('tokenData');

    if (storedToken) {
      const parsedToken = JSON.parse(storedToken);

      saveTokenData(parsedToken, 'tokenAlreadyStored');
      fetchSessionInfo(parsedToken);
    } else {
      fetchSessionInfo(null);
    }
  }

  useEffect(() => {
    const url = new URL(window.location.href);
    const { hash } = url;

    if (hash.includes('token=') || hash.includes('refreshToken=')) {
      extractTokenFromURL(hash);
    } else {
      verifyIfHasActiveSession();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    isReadyToRender,
    firstName,
    setFirstName,
    fetchBalance,
  };
};

export default useTokenHandler;
