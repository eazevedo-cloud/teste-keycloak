import { useEffect, useState } from 'react';

const useDevice = (device: 'desktop' | 'tablet' | 'mobile') => {
  const [ww, setWW] = useState(0);

  useEffect(() => {
    const getWW = () => setWW(window.innerWidth);
    getWW();

    window.addEventListener('resize', getWW);
    return () => window.removeEventListener('resize', getWW);
  }, []);

  switch (device) {
    case 'desktop':
      if (ww > 1050) return true;
      return false;

    case 'tablet':
      if (ww < 1050 && ww > 724) return true;
      return false;

    case 'mobile':
      if (ww < 725) return true;
      return false;

    default:
      return false;
  }
};

export default useDevice;
