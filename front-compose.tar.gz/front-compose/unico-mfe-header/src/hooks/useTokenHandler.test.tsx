import { renderHook, act } from '@testing-library/react-hooks';
import useTokenHandler from '@hooks/useTokenHandler';
import { useAuth } from 'contexts';

jest.mock('contexts', () => ({
  useAuth: jest.fn(),
}));

const mockUserInfo = {
  name: 'John Doe',
  document: '12345678901',
  accounts: [
    { name: 'Account 1', document: '12345678901' },
    { name: 'Account 2', document: '98765432100' },
  ],
};

let originalLocation: Location;

jest.mock('jwt-decode', () => ({
  jwtDecode: () => mockUserInfo,
}));

jest.mock('@utils/events', () => ({
  goPointsEvent: jest.fn(),
}));

describe('useTokenHandler', () => {
  const mockUseAuth = useAuth as jest.Mock;

  const mockSessionToken = {
    token: 'mockToken',
    refreshToken: 'mockRefreshToken',
    expiresIn: 3600,
    refreshExpiresIn: 7200,
    document: '12345678901',
  };

  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
    mockUseAuth.mockReturnValue({
      userInfo: null,
      setUserInfo: jest.fn(),
      fetchBalance: jest.fn(),
      saveTokenData: jest.fn(),
    });
    originalLocation = window.location;
    delete (window as any).location;
    window.location = { ...originalLocation, href: 'http://localhost/' } as Location;
  });

  afterEach(() => {
    localStorage.clear();
    window.location = originalLocation;
  });

  it('should set the first name and ready state when userInfo is set', () => {
    const { result } = renderHook(() => useTokenHandler());

    act(() => {
      mockUseAuth().setUserInfo(mockUserInfo);
      result.current.setFirstName('John');
    });

    expect(result.current.firstName).toBe('John');
    expect(result.current.isReadyToRender).toBe(true);
  });

  it('should extract token from URL and save session data', () => {
    const mockSaveTokenData = mockUseAuth().saveTokenData;
    const hash = '#token=mockToken&refreshToken=mockRefreshToken&expiresIn=3600&refreshExpiresIn=7200&document=12345678901';

    Object.defineProperty(window, 'location', {
      value: { href: `http://localhost/${hash}` },
      writable: true,
    });

    renderHook(() => useTokenHandler());

    expect(mockSaveTokenData).toHaveBeenCalledWith({
      token: 'mockToken',
      refreshToken: 'mockRefreshToken',
      expiresIn: 3600,
      refreshExpiresIn: 7200,
      document: '12345678901',
    });
  });

  it('should verify if there is an active session and set user info', () => {
    const storedToken = JSON.stringify(mockSessionToken);
    localStorage.setItem('tokenData', storedToken);

    renderHook(() => useTokenHandler());
    const mockSaveTokenData = mockUseAuth().saveTokenData;

    expect(mockSaveTokenData).toHaveBeenCalledWith(mockSessionToken, 'tokenAlreadyStored');
    expect(mockUseAuth().setUserInfo).toHaveBeenCalledWith({
      name: 'Account 1',
      document: '12345678901',
      accounts: mockUserInfo.accounts,
    });
  });
});
