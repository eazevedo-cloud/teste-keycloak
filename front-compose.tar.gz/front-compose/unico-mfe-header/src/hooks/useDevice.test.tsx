import { renderHook, act } from '@testing-library/react-hooks';
import useDevice from './useDevice';

describe('useDevice', () => {
  it('should return true for desktop when width is greater than 1050', () => {
    global.innerWidth = 1200;
    const { result } = renderHook(() => useDevice('desktop'));
    act(() => {
      global.dispatchEvent(new Event('resize'));
    });
    expect(result.current).toBe(true);
  });

  it('should return true for tablet when width is between 725 and 1050', () => {
    global.innerWidth = 800;
    const { result } = renderHook(() => useDevice('tablet'));
    act(() => {
      global.dispatchEvent(new Event('resize'));
    });
    expect(result.current).toBe(true);
  });

  it('should return true for mobile when width is less than 725', () => {
    global.innerWidth = 500;
    const { result } = renderHook(() => useDevice('mobile'));
    act(() => {
      global.dispatchEvent(new Event('resize'));
    });
    expect(result.current).toBe(true);
  });
});
