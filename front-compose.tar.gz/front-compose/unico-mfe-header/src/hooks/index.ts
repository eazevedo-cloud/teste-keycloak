import useDevice from "./useDevice";
import useOnline from "./useOnline";

export { useDevice, useOnline };
