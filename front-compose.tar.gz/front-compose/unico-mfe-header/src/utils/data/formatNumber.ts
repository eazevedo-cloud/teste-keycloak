/**
 * Formatação numérica básica.
 *
 * @param n - O número a ser formatado.
 * @returns Retorna o número formatado no formato string.
 */
export function formatNumber(n: number | string): string {
  let formattedNumber: string;

  typeof n === 'number'
    ? (formattedNumber = n.toFixed())
    : (formattedNumber = n);

  return formattedNumber.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}
