import { formatNumber } from './formatNumber';

describe('formatNumber', () => {
  it('should format a number with thousands separator', () => {
    expect(formatNumber(1000)).toBe('1.000');
    expect(formatNumber(123456789)).toBe('123.456.789');
  });

  it('should format a string representing a number with thousands separator', () => {
    expect(formatNumber('1000')).toBe('1.000');
    expect(formatNumber('987654321')).toBe('987.654.321');
  });

  it('should format a number less than 1000 without separator', () => {
    expect(formatNumber(999)).toBe('999');
    expect(formatNumber(0)).toBe('0');
  });

  it('should format a string representing a number less than 1000 without separator', () => {
    expect(formatNumber('999')).toBe('999');
    expect(formatNumber('0')).toBe('0');
  });

  it('should handle negative numbers correctly', () => {
    expect(formatNumber(-1000)).toBe('-1.000');
    expect(formatNumber('-987654')).toBe('-987.654');
  });

  it('should return the input if it is not a valid number', () => {
    expect(formatNumber('not a number')).toBe('not a number');
  });
});
