// Colors
export const MAIN_PRIMARY: string = '#00A370';
export const TEXT_PRIMARY: string = '#3E3E3C';
export const TEXT_SECONDARY: string = '#616161';
export const HOVER: string = '#f6f6f6';

// Animation
export const EASE: string = 'cubic-bezier(0.865, 0.14, 0.095, 0.87)';

// Devices
export const DESKTOP: string = 'min-width: 1050px';
export const TABLET: string = 'max-width: 1049px';
export const MOBILE: string = 'max-width: 724px';
export const SMALL: string = 'max-width: 445px';
