import { css } from "@emotion/react";
import { MAIN_PRIMARY } from "./constants";

export const Reset = css`
  @import url("https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,700&display=swap");

  /* Pseudo-element */
  /* Custom text selection */
  ::-moz-selection {
    background: ${MAIN_PRIMARY};
    color: #fff;
  }
  ::selection {
    background: ${MAIN_PRIMARY};
    color: #fff;
  }

  /* List */
  ul {
    margin: 0;
    padding: 0;
    list-style: none;
  }

  /* Input */
  /* Default eyeicon on Edge */
  input::-ms-reveal,
  input::-ms-clear {
    display: none;
  }

  /* Autofill background color on Chrome/Safari */
  input:-webkit-autofill,
  input:-webkit-autofill:hover,
  input:-webkit-autofill:focus,
  input:-webkit-autofill:active {
    -webkit-background-clip: text;
  }

  /* MUI error icon */
  .MuiFormHelperText-root svg {
    display: none;
  }
`;
