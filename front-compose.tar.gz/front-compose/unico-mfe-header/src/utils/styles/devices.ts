/**
 * Checa o tamanho atual da tela.
 *
 * @param device - O tipo de dispositivo a ser checado (desktop, tablet ou mobile).
 * @returns `true` caso a largura da tela esteja de acordo com o dispositivo checado; `false` caso contrário.
 */
function device(device: 'desktop' | 'tablet' | 'mobile') {
  const ww = window.innerWidth;

  switch (device) {
    case 'desktop':
      if (ww > 1050) return true;
      return false;

    case 'tablet':
      if (ww < 1050 && ww > 724) return true;
      return false;

    case 'mobile':
      if (ww < 725) return true;
      return false;
  }
}

export const isDesktop = device('desktop');
export const isTablet = device('tablet');
export const isMobile = device('mobile');
