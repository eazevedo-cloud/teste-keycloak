import { validateCPF } from './validateCPF';

describe('validateCPF', () => {
  it('should return false for CPF with incorrect length', () => {
    expect(validateCPF('123')).toBe(false);
    expect(validateCPF('123456789012')).toBe(false);
  });

  it('should return false for CPF with invalid repetitions', () => {
    expect(validateCPF('00000000000')).toBe(false);
    expect(validateCPF('11111111111')).toBe(false);
    expect(validateCPF('22222222222')).toBe(false);
    expect(validateCPF('33333333333')).toBe(false);
  });

  it('should return false for CPF with incorrect check digits', () => {
    expect(validateCPF('12345678900')).toBe(false);
    expect(validateCPF('12345678912')).toBe(false);
  });

  it('should return true for a valid CPF', () => {
    expect(validateCPF('52998224725')).toBe(true);
    expect(validateCPF('93541134780')).toBe(true);
  });

  it('should return true for CPF with valid formatting', () => {
    expect(validateCPF('529.982.247-25')).toBe(true);
    expect(validateCPF('935.411.347-80')).toBe(true);
  });

  it('should return false for empty or non-numeric input', () => {
    expect(validateCPF('')).toBe(false);
    expect(validateCPF('abc.def.ghi-jk')).toBe(false);
    expect(validateCPF('!@#$%^&*()_+')).toBe(false);
  });
});
