import { validateCPF } from './validateCPF';

export { validateCPF };
