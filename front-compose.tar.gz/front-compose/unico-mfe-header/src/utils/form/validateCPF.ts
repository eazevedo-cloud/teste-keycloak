/**
 * Validação de CPF.
 *
 * @param {string} cpf - O CPF a ser validado.
 * @returns {boolean} Retorna `true` se o CPF for válido, `false` caso contrário.
 */
export function validateCPF(cpf: string): boolean {
  let Soma: number = 0;
  let Resto: number;
  let i: number;

  // Remoção da formatação da máscara
  cpf = cpf.replace(/[^\d]/g, '');

  // Conferindo o tamanho
  if (cpf.length !== 11) return false;

  // Repetições inválidas conhecidas
  if (
    [
      '00000000000',
      '11111111111',
      '22222222222',
      '33333333333',
      '44444444444',
      '55555555555',
      '66666666666',
      '77777777777',
      '88888888888',
      '99999999999',
    ].indexOf(cpf) !== -1
  ) { return false; }

  // Primeiro dígito verificador
  for (i = 1; i <= 9; i++) Soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);

  Resto = (Soma * 10) % 11;

  if (Resto === 10 || Resto === 11) Resto = 0;
  if (Resto !== parseInt(cpf.substring(9, 10))) return false;

  // Segundo dígito verificador
  Soma = 0;

  for (i = 1; i <= 10; i++) Soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);

  Resto = (Soma * 10) % 11;

  if (Resto === 10 || Resto === 11) Resto = 0;
  if (Resto !== parseInt(cpf.substring(10, 11))) return false;

  return true;
}
