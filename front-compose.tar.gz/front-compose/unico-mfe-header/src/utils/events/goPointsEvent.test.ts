import { goPointsEvent } from './goPointsEvent';

describe('goPointsEvent', () => {
  let dispatchEventSpy: jest.SpyInstance;

  beforeEach(() => {
    dispatchEventSpy = jest.spyOn(window, 'dispatchEvent');
  });

  afterEach(() => {
    dispatchEventSpy.mockRestore();
  });

  it('should dispatch an event with the correct name and details when user is provided', () => {
    const user = { name: 'John Doe', document: '123456789', accounts: [] };
    const name = 'testEvent';
    const message = 'Test message';
    const path = '/test/path';
    const accessToken = 'abc123';

    goPointsEvent(name, message, path, user, accessToken);

    expect(dispatchEventSpy).toHaveBeenCalledTimes(1);
    const event = dispatchEventSpy.mock.calls[0][0] as CustomEvent;
    expect(event.type).toBe(name);
    expect(event.detail).toEqual({
      message,
      path,
      user: {
        name: 'John Doe',
        document: '123456789',
      },
      access_token: 'abc123',
    });
  });

  it('should dispatch an event with empty user details when user is null', () => {
    const name = 'testEvent';
    const message = 'Test message';
    const path = '/test/path';

    goPointsEvent(name, message, path, null);

    expect(dispatchEventSpy).toHaveBeenCalledTimes(1);
    const event = dispatchEventSpy.mock.calls[0][0];
    expect(event.type).toBe(name);
    expect(event.detail).toEqual({
      message,
      path,
      user: {
        name: '',
        document: '',
      },
    });
  });

  it('should not include access_token in event details if not provided', () => {
    const user = { name: 'Jane Doe', document: '987654321', accounts: [] };
    const name = 'testEvent';
    const message = 'Test message';
    const path = '/test/path';

    goPointsEvent(name, message, path, user);

    expect(dispatchEventSpy).toHaveBeenCalledTimes(1);
    const event = dispatchEventSpy.mock.calls[0][0];
    expect(event.type).toBe(name);
    expect(event.detail).toEqual({
      message,
      path,
      user: {
        name: 'Jane Doe',
        document: '987654321',
      },
    });
  });
});
