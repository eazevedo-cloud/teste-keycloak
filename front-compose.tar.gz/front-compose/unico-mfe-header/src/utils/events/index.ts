import { goPointsEvent } from './goPointsEvent';

export { goPointsEvent };
