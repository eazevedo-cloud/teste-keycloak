import { UserInfo } from '../../types/user';

/**
 * Criação de novo evento para a GoPoins.
 *
 * @param name - O nome do novo evento a ser criado;
 * @param message - A mensagem sobre o novo evento;
 * @param path - O caminho relativo da origem do novo evento;
 * @param user - As informações do usuário ativo, caso exista;
 * @param {String} [accessToken] - Token de acesso.
 */
export function goPointsEvent(
  name: string,
  message: string,
  path: string,
  user: UserInfo | null,
  accessToken?: string,
) {
  const event = new CustomEvent(name, {
    detail: {
      message,
      path,
      user: {
        name: user ? user.name : '',
        document: user ? user.document : '',
      },
      ...(accessToken && { access_token: accessToken }),
    },
  });

  window.dispatchEvent(event);
}
