import { JwtPayload } from "jwt-decode";

export type Account = {
  name: string;
  document: string;
};

export interface AccessToken extends JwtPayload {
  accounts: Account[];
  name: string;
  preferred_username: string;
}

export interface SessionTokenData {
  token: string;
  refreshToken: string;
  expiresIn: number;
  refreshExpiresIn: number;
  document?: string;
}

export interface RefreshTokenResponse {
  access_token: string;
  refresh_token: string;
  expires_in: number;
  refresh_expires_in: number;
}
