import { AccessToken, Account } from './accessToken';

export interface UserInfo {
  name: Account["name"];
  document: Account["document"];
  accounts: AccessToken["accounts"];
}
