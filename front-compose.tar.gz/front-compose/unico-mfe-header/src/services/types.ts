export type GetBalanceResponse = {
  available: number
}