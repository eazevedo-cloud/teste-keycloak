import { EventEmitter } from 'events';

export const authEventEmitter = new EventEmitter();
