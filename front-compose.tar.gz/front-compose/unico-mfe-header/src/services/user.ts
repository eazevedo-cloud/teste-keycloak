import api from "./api";

const balancePath = "/balance";

export async function getUserBalance(document: string) {
  const response = await api.get(`${balancePath}/${document}`);

  return response.data;
}
