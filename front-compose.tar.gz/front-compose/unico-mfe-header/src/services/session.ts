import { RefreshTokenResponse } from '@interfaces/accessToken';
import api from "./api";

const loginPath = "login";

export async function logoutUser() {
  const response = await api.delete(`/${loginPath}`, {
    headers: { "Traffic-Key": "v1a" },
  });

  return response.data;
}

export async function refreshSession(
  refreshToken: string,
): Promise<RefreshTokenResponse> {
  const response = await api.post(
    `/${loginPath}/refresh`,
    { refresh_token: refreshToken },
    {
      headers: { "Traffic-Key": "v1a" },
    },
  );

  return response.data;
}
