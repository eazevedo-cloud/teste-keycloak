/* eslint-disable no-param-reassign */
import { SessionTokenData } from '@interfaces/accessToken';
import axios, { AxiosInstance } from 'axios';
import { refreshSession } from './session';
import { authEventEmitter } from './authEventEmitter';

const axiosInstance: AxiosInstance = axios.create({
  baseURL: process.env.URL_BFF,
  timeout: 15000,
});

let isRefreshing = false;

axiosInstance.interceptors.request.use(
  async (config) => {
    if (!isRefreshing) {
      const storedToken = localStorage.getItem('tokenData') as string;
      const session: SessionTokenData = JSON.parse(storedToken);

      config.headers.Authorization = session.token;

      const currentTime = new Date().getTime();
      const tokenExpirationTime = session.expiresIn;
      const refreshTokenExpirationTime = session.refreshExpiresIn;

      if (tokenExpirationTime && currentTime > tokenExpirationTime) {
        if (
          refreshTokenExpirationTime
          && currentTime < refreshTokenExpirationTime
        ) {
          isRefreshing = true;
          try {
            const newToken = await refreshSession(session.refreshToken);

            authEventEmitter.emit('tokenUpdated', {
              token: newToken.access_token,
              refreshToken: newToken.refresh_token,
              expiresIn: newToken.expires_in,
              refreshExpiresIn: newToken.refresh_expires_in,
            });
            config.headers.Authorization = newToken.access_token;
          } catch (err) {
            return await Promise.reject(err);
          } finally {
            isRefreshing = false;
          }
        } else {
          authEventEmitter.emit('sessionExpired');
          return Promise.reject(Error('Sessão expirada.'));
        }
      }
    }

    return config;
  },
  (error) => Promise.reject(error),
);

export default axiosInstance;
