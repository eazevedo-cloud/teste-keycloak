export const environment = {
  production: true,
  HEADER_URL: 'https://statics-novoloyalty.test.loyaltyunicred.com.br/unico-mfe-header/unico_mfe_header.js',
  FOOTER_URL: 'https://statics-novoloyalty.test.loyaltyunicred.com.br/unico-mfe-footer/unico_mfe_footer.js'
};
