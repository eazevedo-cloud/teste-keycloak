export const environment = {
  production: false,
  apiUrl: 'https://api.test.prod.com',
  HEADER_URL: 'http://localhost:8080/unico_mfe_header.js',
  FOOTER_URL: 'http://localhost:8081/unico_mfe_footer.js',
};
