import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
// import { environment } from './environments/environment';

async function prepareApp() {
  // if (!environment.production) {
  //   const { makeServer } = await import('./mocks/server');
  //   return makeServer();
  // }

  return Promise.resolve();
}

prepareApp().then(() => {
  platformBrowserDynamic()
    .bootstrapModule(AppModule)
    .catch((err) => console.error(err));
});
