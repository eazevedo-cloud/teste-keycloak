import { Registry, Response, Server } from 'miragejs';
import { balanceData } from './data';
import { AnyModels, AnyFactories } from 'miragejs/-types';

export default function (server: Server<Registry<AnyModels, AnyFactories>>) {
  server.get('/balance/:document', () => {
    return new Response(200, {}, balanceData);
  });
}
