export const balanceData = {
  available: 198547,
  availableLast12Months: 201,
  blocked: 100,
  expirations: [
    {
      toExpire: 150000,
      expiryDate: '10/2024',
    },
    {
      toExpire: 40000,
      expiryDate: '11/2024',
    },
    {
      toExpire: 8547,
      expiryDate: '12/2024',
    },
  ],
};
