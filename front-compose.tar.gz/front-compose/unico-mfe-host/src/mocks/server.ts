import { createServer } from 'miragejs';
import balanceRoutes from './routes/balance';

export function makeServer() {
  const server = createServer({
    routes() {
      (this.urlPrefix =
        'https://unico-bff-cdn.test.loyaltyunicred.com.br/unico/v1'),
        balanceRoutes(this);
    },
  });
  return server;
}
