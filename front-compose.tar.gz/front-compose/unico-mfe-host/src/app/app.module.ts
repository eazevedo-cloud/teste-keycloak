import {
  NgModule,
  APP_INITIALIZER,
  CUSTOM_ELEMENTS_SCHEMA,
} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { loadRemoteModule } from './utils/federation-utils';
import { AppComponent } from './app.component';
import { environment } from 'src/environments/environment';

const routes: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./layout/layout.component').then((m) => m.LayoutComponent),
  },
  {
    path: 'mfe-header',
    loadComponent: () =>
      import('./unico-mfe-header/unico-mfe-header.component').then(
        (m) => m.UnicoMfeHeaderComponent
      ),
  },
  {
    path: 'mfe-footer',
    loadComponent: () =>
      import('./unico-mfe-footer/unico-mfe-footer.component').then(
        (m) => m.UnicoMfeFooterComponent
      ),
  },
];

export function initializeApp(): () => void {
  return () => {
    loadRemoteModule({
      remoteEntry: environment.HEADER_URL,
      remoteName: 'unico_mfe_header',
      exposedModule: './UnicoMfeHeaderComponent',
    });
    loadRemoteModule({
      remoteEntry: environment.FOOTER_URL,
      remoteName: 'unico_mfe_footer',
      exposedModule: './UnicoMfeFooterComponent',
    });
  };
}

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, RouterModule.forRoot(routes)],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: initializeApp,
      multi: true,
    },
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA, // Added for custom elements support
  ],

  bootstrap: [AppComponent],
})
export class AppModule {}
