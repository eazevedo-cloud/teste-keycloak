import {
  Component,
  ElementRef,
  Input,
  Output,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import * as React from 'react';
import { createRoot } from 'react-dom/client';
import { IUser } from '../models/user';
import { UnicoMfeHeaderService } from './unico-mfe-header.service';
import { Observable } from 'rxjs';

const containerElementName = 'customReactComponentContainer';

@Component({
  selector: 'unico-mfe-header',
  template: `<section #${containerElementName}></section>`,
  encapsulation: ViewEncapsulation.None,
  standalone: true,
})
export class UnicoMfeHeaderComponent {
  @Input() user: IUser = {
    name: 'Vinicius',
    email: 'vinicius.moraes@e-unicred.com.br',
  };

  currentUser$: Observable<IUser> = new Observable();

  @ViewChild(containerElementName, { static: true }) containerRef!: ElementRef;
  root!: any;

  constructor(private unicoMfeHeaderService: UnicoMfeHeaderService) {}

  updateCurrentUser(user: IUser) {
    this.unicoMfeHeaderService.setNewCurrentUser(user);
  }

  ngAfterViewInit() {
    this.root = createRoot(this.containerRef.nativeElement);
    this.root.render('Carregando o componente Header...');

    try {
      import('unico_mfe_header/UnicoMfeHeaderComponent').then((mfe) => {
        this.root.render(
          React.createElement(mfe.UnicoMfeHeaderComponent, {
            ...this.user,
          })
        );
      });
    } catch (error) {
      console.error('Erro ao carregar o componente Header:', error);
      this.root.render('Erro ao carregar o componente Header.');
    }
  }

  ngOnDestroy() {
    this.root.unmountComponentAtNode(this.containerRef.nativeElement);
  }
}
