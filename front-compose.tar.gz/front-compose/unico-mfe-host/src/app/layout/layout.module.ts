import { NgModule } from "@angular/core";

import { UnicoMfeHeaderComponent } from "../unico-mfe-header/unico-mfe-header.component";
import { UnicoMfeFooterComponent } from "../unico-mfe-footer/unico-mfe-footer.component";

@NgModule({
  imports: [UnicoMfeHeaderComponent, UnicoMfeFooterComponent],
  providers: [],
})
export class LayoutModule {}
