import { Component } from '@angular/core';
import { UnicoMfeHeaderComponent } from '../unico-mfe-header/unico-mfe-header.component';
import { UnicoMfeFooterComponent } from '../unico-mfe-footer/unico-mfe-footer.component';

@Component({
  standalone: true,
  imports: [UnicoMfeHeaderComponent, UnicoMfeFooterComponent],
  selector: 'app-layout',
  template: `
    <unico-mfe-header></unico-mfe-header>
    <style>
      #gopoints {
        background: #eee;
        height: 100vh;
        font-size: 10vw;
        color: #ddd;
        display: flex;
        justify-content: center;
        align-items: center;
      }
    </style>
    <section id="gopoints">GoPoints</section>
    <unico-mfe-footer></unico-mfe-footer>
  `,
})
export class LayoutComponent {}
