import {
  Component,
  ElementRef,
  Input,
  ViewChild,
  ViewEncapsulation,
  AfterViewInit,
  OnDestroy,
} from '@angular/core';
import * as React from 'react';
import { createRoot } from 'react-dom/client';
import { IUser } from '../models/user';
import { UnicoMfeFooterService } from './unico-mfe-footer.service';
import { Observable } from 'rxjs';

const containerElementName = 'customReactComponentContainer';

@Component({
  selector: 'unico-mfe-footer',
  template: ` <section #${containerElementName}></section>`,
  encapsulation: ViewEncapsulation.None,
  standalone: true,
})
export class UnicoMfeFooterComponent implements AfterViewInit, OnDestroy {
  @Input() user: IUser = {
    name: 'Vinicius',
    email: 'vinicius.moraes@e-unicred.com.br',
  };

  currentUser$: Observable<IUser> = new Observable();

  @ViewChild(containerElementName, { static: true }) containerRef!: ElementRef;
  root!: any;

  constructor(private unicoMfeFooterService: UnicoMfeFooterService) {}

  updateCurrentUser(user: IUser) {
    this.unicoMfeFooterService.setNewCurrentUser(user);
  }

  ngAfterViewInit() {
    this.root = createRoot(this.containerRef.nativeElement);
    this.root.render('Carregando o componente Footer...');

    try {
      import('unico_mfe_footer/UnicoMfeFooterComponent').then((mfe) => {
        this.root.render(
          React.createElement(mfe.UnicoMfeFooterComponent, {
            ...this.user,
          })
        );
      });
    } catch (error) {
      console.error('Erro ao carregar o componente Footer:', error);
      this.root.render('Erro ao carregar o componente Footer.');
    }
  }

  ngOnDestroy() {
    this.root.unmountComponentAtNode(this.containerRef.nativeElement);
  }
}
