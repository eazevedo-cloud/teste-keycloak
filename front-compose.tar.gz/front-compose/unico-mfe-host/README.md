# MFE Host
Projeto simulando o host do miolo da GoPoints e integrando com os componentes MFEs do Header + Multicontas e o Footer.

### Importante: ajustar a configuracao dos MFEs.
./src/app/app.module.ts e webpack.config.ts
`
unico_mfe_header: `unico_mfe_header@http://localhost:8081/unico_mfe_header.js`,
unico_mfe_footer: `unico_mfe_footer@http://localhost:8080/unico_mfe_footer.js`,
`

# Configuração do Ambiente Local com Docker Compose

Este guia fornece instruções para configurar o ambiente local utilizando Docker Compose.

## Pré-requisitos

Antes de começar, certifique-se de ter os seguintes softwares instalados em sua máquina:

- Docker https://www.docker.com/products/docker-desktop/

## Passos para Configuração

1. **Clone o Repositório** Clone o repositório do projeto para sua máquina local.
2. **Configuração do Arquivo .env** Crie um arquivo .env na raiz dos MFEs e adicione as variáveis de ambiente necessárias. Você pode usar o arquivo .env.example como referência:
  ```bash
  cp .env.example .env
  ```
3. **Instalação dos containers do front** Construir e Iniciar os Contêineres Use o Docker Compose para construir e iniciar os contêineres:
  ```bash
  docker-compose up --build -d --remove-orphans
  ```
![img.png](scripts/install-containers.png)

## Comandos Úteis para os Contêineres (caso queria uma interface, use o Docker Desktop)

Aqui estão alguns comandos úteis para gerenciar os contêineres do seu ambiente local:

- Parar e remover os Contêineres
  ```bash
  docker-compose down
  ```
- Parar os Contêineres
  ```bash
  docker-compose stop
  ```  
- Iniciar os Contêineres
  ```bash
  docker-compose start
  ```
- Reiniciar os Contêineres
  ```bash
  docker-compose restart
  ```
- Visualizar Logs
  ```bash
  docker-compose logs -f
  ```
- Executar Comandos dentro do Contêiner Host, use o seguinte comando:
  ```bash
  docker-compose exec <nome-do-serviço> <comando> (ex: npm run build)
  ```
- Acessar o Shell do Contêiner para acessar o shell de um contêiner específico, use:
  ```bash
  docker-compose exec <nome-do-serviço> /bin/bash
  ```
Esses comandos devem ajudar a gerenciar e interagir com os contêineres de forma eficiente. Se precisar de mais algum comando ou tiver dúvidas, sinta-se à vontade para perguntar ao Arquiteto ou LT da equipe!
