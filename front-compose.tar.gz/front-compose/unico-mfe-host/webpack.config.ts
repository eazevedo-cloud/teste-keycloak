import { container } from "webpack";
const deps = require("./package.json").dependencies;
const dotenv = require("dotenv");

const env = dotenv.config().parsed;

module.exports = {
  output: {
    uniqueName: "unico-mfe-host",
    scriptType: "text/javascript",
  },
  optimization: {
    runtimeChunk: false,
  },
  devServer: {
    port: 4201,
    headers: {
      "Access-Control-Allow-Origin": "*",
    },
    hot: true,
  },
  plugins: [
    new container.ModuleFederationPlugin({
      name: "unico-mfe-host",
      filename: "unico-mfe-host.js",
      remotes: {
        unico_mfe_header: `unico_mfe_header@${env.HEADER_URL}`,
        unico_mfe_footer: `unico_mfe_footer@${env.FOOTER_URL}`,
      },
      shared: {
        react: {
          singleton: true,
          requiredVersion: deps.react,
        },
        "react-dom": {
          singleton: true,
          requiredVersion: deps["react-dom"],
        },
      },
    }),
  ],
};
